#import
from Class_Menu import *
from funciones_validaciones import *

#Menu Configuracion - opcion 2 - menú Abrir app - App Configuración - Modificar nombre
def modificar_nombre(telefono):
    print(f'El nombre de su teléfono es {telefono.nombre}')
    nombre_valido = False
    while not nombre_valido:
        nuevo_nombre = input("Ingrese el nuevo nombre para el teléfono: ")
        if validarNombre(nuevo_nombre):
            telefono.nombre = nuevo_nombre
            nombre_valido = True
            print(f"El nombre del teléfono se ha cambiado a {telefono.nombre}")
        else:
            print("Error: El nombre no es válido. Intente nuevamente.")

#Menu Configuracion - opcion 2 - menú Abrir app - App Configuración - Configurar código

def configurar_codigo(telefono):
    if telefono.codigo_desbloqueo:
        gestionar_cambio_codigo(telefono)
    else:
        establecer_nuevo_codigo(telefono)

def gestionar_cambio_codigo(telefono):
    cod = input("Ingrese su código anterior: ")
    if cod == telefono.codigo_desbloqueo:
        establecer_nuevo_codigo(telefono)
    else:
        print("Código incorrecto.")

def establecer_nuevo_codigo(telefono):
    cod_nuevo_valido = False
    while not cod_nuevo_valido:
        cod_nuevo = input("Ingrese su nuevo código: ")
        if validarCodigo(cod_nuevo):
            telefono.codigo_desbloqueo = cod_nuevo
            cod_nuevo_valido = True
            print("Nuevo código establecido")
        else:
            print("Código no válido. Intente nuevamente.")

#Menú principal - opción 2 - menú Abrir app - App Configuración - main

def definir_opciones_configuracion(telefono_operando):
    opcion_x_estado=None
    if telefono_operando.red_movil=="Desactivada" and telefono_operando.internet=="Desactivado":
        opciones_configuracion = {"1":"Modificar nombre del teléfono","2":"Configurar código de desbloqueo","3":"Activar red móvil","4":"Activar conectividad a internet","5":"Salir"}
        opcion_x_estado="1"
    elif not telefono_operando.red_movil=="Desactivada" and not telefono_operando.internet=="Desactivado":
        opciones_configuracion = {"1":"Modificar nombre del telefono","2":"Configurar codigo de desbloqueo","3":"Desactivar red movil","4":"Desactivar conectividad a internet","5":"Salir"}
        opcion_x_estado="2"
    elif telefono_operando.red_movil=="Desactivada" and not telefono_operando.internet=="Desactivado":
        opciones_configuracion = {"1":"Modificar nombre del telefono","2":"Configurar codigo de desbloqueo","3":"Activar red movil","4":"Desactivar conectividad a internet","5":"Salir"}
        opcion_x_estado="3"
    elif not telefono_operando.red_movil=="Desactivada" and telefono_operando.internet=="Desactivado":
        opciones_configuracion = {"1":"Modificar nombre del telefono","2":"Configurar codigo de desbloqueo","3":"Desactivar red movil","4":"Activar conectividad a internet","5":"Salir"}
        opcion_x_estado="4"
    
    return opciones_configuracion,opcion_x_estado

def menuConfiguracion(telefono):
    sigue = True
    while sigue:
        texto_configuracion = "\nElija la opción que desee:"
        opciones_configuracion, opcion_x_estado = definir_opciones_configuracion(telefono)
        menu_configuracion = Menu(opciones_configuracion, texto_configuracion)
        opcion_configuracion = menu_configuracion.pedir_opcion()

        match opcion_x_estado:
            case "1":
                sigue = manejar_opcion_configuracion_estado_1(telefono, opcion_configuracion)
            case "2":
                sigue = manejar_opcion_configuracion_estado_2(telefono, opcion_configuracion)
            case "3":
                sigue = manejar_opcion_configuracion_estado_3(telefono, opcion_configuracion)
            case "4":
                sigue = manejar_opcion_configuracion_estado_4(telefono, opcion_configuracion)

def manejar_opcion_configuracion_estado_1(telefono, opcion_configuracion):
    match opcion_configuracion:
        case "1":
            modificar_nombre(telefono)
        case "2":
            configurar_codigo(telefono)
        case "3":
            telefono.activar_red_movil()
        case "4":
            telefono.activar_conexion()
        case "5":
            return False
    return True

def manejar_opcion_configuracion_estado_2(telefono, opcion_configuracion):
    match opcion_configuracion:
        case "1":
            modificar_nombre(telefono)
        case "2":
            configurar_codigo(telefono)
        case "3":
            telefono.desactivar_red_movil()
        case "4":
            telefono.desactivar_conexion()
        case "5":
            return False
    return True

def manejar_opcion_configuracion_estado_3(telefono, opcion_configuracion):
    match opcion_configuracion:
        case "1":
            modificar_nombre(telefono)
        case "2":
            configurar_codigo(telefono)
        case "3":
            telefono.activar_red_movil()
        case "4":
            telefono.desactivar_conexion()
        case "5":
            return False
    return True

def manejar_opcion_configuracion_estado_4(telefono, opcion_configuracion):
    match opcion_configuracion:
        case "1":
            modificar_nombre(telefono)
        case "2":
            configurar_codigo(telefono)
        case "3":
            telefono.desactivar_red_movil()
        case "4":
            telefono.activar_conexion()
        case "5":
            return False
    return True