from Class_AppTelefono import *
from Class_Contactos import *
from Class_Mensajeria import *
from Class_AppStore import *
from Class_AppEmail import *
from Class_Configuracion import *

class Telefono:
    modelos_disponibles = {'1': {"Nombre":'Iphone 12',"RAM":"4"}, '2': {"Nombre":'Iphone 15',"RAM":"6"}, '3': {"Nombre":'Samsung Galaxy Flip 5',"RAM":"8"}, '4': {"Nombre":'Samsung Galaxy s24',"RAM":"12"}} ##Posibles modelos de teléfono entre los cuales va a elegir el usuario. Usamos un diccionario porque para cada clave, que es el numero que ingresa el usuario en el menú, se le asocia el modelo seleccionado y a su vez la memoria RAM de ese modelo
    almacenamientos_disponibles = {'1': '32', '2': '64', '3': '128', '4': '256', '5': '512'} ##Los posibles almacenamientos de cada modelo de teléfono. El usuario elige el número y se le asocia una cantidad de GB de almacenamiento
    telefonos={} #key: id, valor: objeto teléfono. Usamos un diccionario porque los id son únicos y para poder acceder a través de cada id a cada teléfono
    def __init__(self, *args): #args funciona como una lista
        if len(args)==6:
            self.id=args[0] #int, el id se asigna por medio de una función que aumenta en 1 el id automáticamente recorriendo el CSV
            self.nombre=args[1] #str, por default se asigna el mismo nombre "Mi teléfono" a cada teléfono y si el usuario quiere, lo cambia al momento de instanciar el teléfono
            self.modelo=self.asignarModelo(args[2]) #str, el modelo se asigna por medio de una función que retorna el modelo seleccionado por el usuario
            self.sist_operativo=self.asignarSistOperativo() #El sistema operativo se asigna por un método que analiza el modelo y si es Iphone, el sistema operativo es iOS, si es Samsung, el sistema es Android
            self.version=self.asignarVersion() #La versión se asigna dependiendo de qué sistema operativo es
            self.memoria_ram=self.asignarMemoriaRAM(args[2]) #La memoria RAM se asigna según el modelo que eligió el usuario
            self.almacenamiento=self.asignarAlmacenamiento(args[3]) ##El almacenamiento se asigna por medio de una función que retorna el almacenamiento seleccionado por el usuario
            self.num_telefono=args[4]
            self.codigo_desbloqueo=args[5]
            self.red_movil="Desactivada" #por default se asigna la red móvil desactivada
            self.internet="Desactivado" #por default se asigna el internet desactivado
            self.prendido=False #por defualt el teléfono está apagado
            self.desbloqueado=False #por default el teléfono está bloqueado
            self.apps=self.instanciar_apps_basicas()
            
        elif len(args)==14:
            self.id=args[0]
            self.nombre=args[1]
            self.modelo=args[2]
            self.sist_operativo=args[3]
            self.version=args[4]
            self.memoria_ram=args[5]
            self.almacenamiento=args[6]
            self.num_telefono=args[7]
            self.codigo_desbloqueo=args[8]
            self.red_movil=args[9]
            self.internet=args[10]
            self.prendido=args[11]
            self.desbloqueado=args[12]
            self.apps=args[13]
        
        else:
            raise ValueError(f"Se esperaban 6 o 13 argumentos, pero se recibieron {len(args)}")
    
        Telefono.telefonos[self.id]=self #cada vez que se instancia un teléfono se agrega su id como clave al diccionario y la instancia del objeto como valor
    
    def asignarModelo(self, opcion_elegida:str): ##Devuelve el modelo asociado a la opción seleccionada por el usuario. Recibe como parámetro la opción
        return Telefono.modelos_disponibles[opcion_elegida]['Nombre']
    
    def asignarSistOperativo(self): ##asogna el sist op de acuerdo al tipo de telefono
        if 'Iphone' in self.modelo:
            return "iOS"
        elif 'Samsung' in self.modelo:
            return "Android"
    
    def asignarVersion(self):
        if self.sist_operativo=="iOS":
            return "18.0.1" #esta es la última versión de sistema operativo de iOS
        else:
            return "6.0"#esta es la última versión de sistema operativo de Android
    
    def asignarMemoriaRAM(self,opcion_elegida:str): #Devuelve la memoria RAM asociada al modelo del teléfono
        return Telefono.modelos_disponibles[opcion_elegida]["RAM"]
    
    def asignarAlmacenamiento(self, opcion_elegida): ##Devuelve el almacenamiento asociado a la opción seleccionada por el usuario. Recibe como parámetro la opción
        return Telefono.almacenamientos_disponibles[opcion_elegida]
    
    def prenderse(self): #Método para prender el teléfono
        if not self.prendido: #Si el teléfono está apagado, cambia el atributo de instancia "prendido" a True
            self.prendido=True
            self.activar_red_movil()
            print("Teléfono prendido correctamente")
        else: 
            print("Error: su télefono ya estaba prendido")
    
    #recorre todas las aplicaciones del teléfo y cierra cada una de ellas
    def cerrar_apps(self):
        for app in self.apps.values():
            if app.ejecucion==True:
                app.cerrar_app()
    
    @classmethod
    def apagar_todos(cls):
        for telefono in cls.telefonos.values():
            telefono.prendido=False
            telefono.desbloqueado=False
            telefono.red_movil='Desactivada'
            telefono.cerrar_apps()
            telefono.apps["Telefono"].cortarParaApagar()
    
    def apagarse(self): #Método para apagar el teléfono
        if self.prendido: #Si el teléfono está prendido, cambia el atributo de instancia "prendido" a False
            self.prendido = False
            if self.desbloqueado == True:
                self.desbloqueado = False
            self.cerrar_apps()
            self.desactivar_red_movil()
            self.apps["Telefono"].cortarParaApagar()
            print("Teléfono apagado correctamente")
        else:
            print("Error: su teléfono ya estaba apagado")
    
    def bloquearse(self): #Método para bloquear el teléfono
        if self.desbloqueado and self.prendido: #Si el teléfono está desbloqueado, cambia el atributo de instancia "desbloqueado" a False
            self.desbloqueado=False
            print("Teléfono bloqueado correctamente")
        else:
            print("Error: su teléfono ya estaba bloqueado o estaba apagado")
    
    def validarEntradaCodigoAcceso(self): #Método para validar el código de acceso, se llama a este método dentro del método "desbloquearse"
        cumple=False
        while not cumple:
            codigo=input("Ingrese el código para desbloquear su teléfono: ")
            if codigo == self.codigo_desbloqueo: #Verifica que el código ingresado por el usuario para intentar desbloquear el teléfono sea igual al código de desbloqueo del teléfono
                cumple= True
            else:
                print("Error: el código ingresado es incorrecto")
        return cumple
    
    def desbloquearse(self): #Método para desbloquear el teléfono
        if self.desbloqueado==False and self.prendido: #Si el teléfono está bloqueado, verifica que el código de acceso sea correcto y recién ahí cambia el atributo de instancia "desbloqueado" a True
            if self.validarEntradaCodigoAcceso():
                self.desbloqueado=True
                print("Teléfono desbloqueado correctamente")
        else:
            print("Error: su teléfono ya estaba desbloqueado o se encuentra apagado")
    
    def verificar_prendido_desbloqueado(self):
        if self.desbloqueado and self.prendido:
            return True
        print("Error: el telefono está bloqueado o apagado (prendalo con opción 1 y desbloqueelo con opción 4)")
        return False
    
    def abrirApp(self,app:Aplicacion):
        if self.verificar_prendido_desbloqueado():
            app.abrir_app()
        else:
            print("Error: debe prender y desbloquear su telefono para abrir una app")
    
    def cerrar_app(self, app:Aplicacion):
        if self.verificar_prendido_desbloqueado():
            app.cerrar_app()
        else:
            print("Error: debe prender y desbloquear su telefono para poder acceder a una app")
    
    def activar_red_movil(self):
        if self.red_movil == 'Desactivada':
            self.red_movil = 'Activada'
            print('Red movil activada')
        else:
            print('La red movil ya estaba activada')

    def desactivar_red_movil(self):
        if self.red_movil == 'Activada':
            self.red_movil = 'Desactivada'
            print('Red movil desactivada')
        else:
            print('La red movil ya estaba desactivada')

    def activar_conexion(self):
        if self.internet == 'Desactivado':
            self.internet = 'Activado'
            print('Conexion a internet activado')
        else:
            print('La conexion a internet ya estaba activada')

    def desactivar_conexion(self):
        if self.internet == 'Activado':
            self.internet = 'Desactivado'
            print('Conexion a internet desactivado')
        else:
            print('La conexion a internet ya estaba desactivada')
    
    @classmethod
    def telefonosParaOperar(cls):
        telefonos_dispo=[]
        for id,telefono in cls.telefonos.items():
            telefonos_dispo.append([id,f"Nombre: {telefono.nombre} - Numero de telefono: {telefono.num_telefono}"])
    
        return telefonos_dispo
    
    def appsParaOperar(self):
        return list(self.apps.keys())
    
    def instanciar_apps_basicas(self): ##Instancia todas las apps basicas del programa
        apps_celu={}
        for nombre, app in Aplicacion.apps_basicas.items():
            if nombre=="Telefono":
                apps_celu[nombre]=AppTelefono()
            elif nombre=="Contactos":
                apps_celu[nombre]=Contacto()
            elif nombre=="Mensajes":
                apps_celu[nombre]=Mensajes()
            elif nombre=="Email":
                apps_celu[nombre]=AppEmail()
            elif nombre=="AppStore":
                apps_celu[nombre]=AppStore()
            elif nombre=="Configuracion":
                apps_celu[nombre]=Configuracion()
            else:
                apps_celu[nombre]=Aplicacion(nombre)
        return apps_celu
    
    def nombre_ejecucion_apps(self):
        apps_para_csv={}
        for nombre,app in self.apps.items():
            if nombre=="Telefono":
                apps_para_csv[nombre]=(app.ejecucion,app.historial_llamadas,app.llamada_en_curso)
            elif nombre=="Contactos":
                apps_para_csv[nombre]=(app.ejecucion,app.contactos)
            elif nombre=="Mensajes":
                apps_para_csv[nombre]=(app.ejecucion,)
            elif nombre=="Email":
                bandeja_x_noleido=tuple((email.remitente,email.destinatario,email.asunto,email.contenido,email.fecha.isoformat(),email.leido) for email in app.bandeja_x_noleido)
                bandeja_x_fecha=tuple((email.remitente,email.destinatario,email.asunto,email.contenido,email.fecha.isoformat(),email.leido) for email in app.bandeja_x_fecha)
                apps_para_csv[nombre]=(app.ejecucion,app.direccion_remitente,app.agenda_emails,bandeja_x_noleido,bandeja_x_fecha)
            elif nombre=="AppStore":
                apps_para_csv[nombre]=(app.ejecucion,app.obtener_nombres_apps_instaladas())
            else:
                apps_para_csv[nombre]=(app.ejecucion,)
        return apps_para_csv
    
    def __str__(self):
        return f"\nDatos del teléfono:\nID: {self.id}\nNombre: {self.nombre}\nModelo: {self.modelo}\nSistema operativo: {self.sist_operativo}\nVersión: {self.version}\nCapacidad de memoria RAM: {self.memoria_ram}\nCapacidad de almacenamiento: {self.almacenamiento}\nNúmero de teléfono: {self.num_telefono}\nCódigo de desbloqueo: {self.codigo_desbloqueo}\nEstado de la red móvil: {self.red_movil}\nEstado de la conectividad a Internet: {self.internet}\nEl teléfono está prendido: {self.prendido}\nEl teléfono está desbloqueado: {self.desbloqueado}\nLas apps del teléfono son: {self.apps.keys()}"