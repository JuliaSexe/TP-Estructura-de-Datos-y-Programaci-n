#import
from Class_Menu import *

#Menú principal - opción 2 - menú Abrir app - app AppStore

def menuAppStore(telefono_operando):
    texto_appstore = "\nElija la opción que desee: "
    if len(telefono_operando.apps["AppStore"].apps_instaladas)>0:
        opciones_appstore = {"1":"Descargar una nueva app","2":"Ver apps instaladas","3":"Eliminar una app","4":"Volver al menú principal"}
    else:
        opciones_appstore = {"1":"Descargar una nueva app","2":"Ver apps instaladas","3":"Volver al menú principal"}
    menu_appstore = Menu(opciones_appstore,texto_appstore)
    opcion_appstore=menu_appstore.pedir_opcion()
    return opcion_appstore

#Menú principal - opción 2 - menú Abrir app - app AppStore - opción 1

def menu_opcion1_appstore(telefono_operando):
    texto_appstore = "\nSeleccione la aplicación que desea instalar: "
    opciones_appstore = list(telefono_operando.apps["AppStore"].apps_disponibles.keys())
    opciones_appstore.append("Volver al menu principal")
    menu_appstore = Menu(opciones_appstore,texto_appstore)
    opcion_app=menu_appstore.pedir_opcion()
    app=opciones_appstore[int(opcion_app)-1]
    return app
    
def opcion1_menu_appstore(telefono_operando):
    telefono_operando.apps["AppStore"].mostrar_apps_disponibles()
    cumple=False
    while not cumple:
        nombre_app=menu_opcion1_appstore(telefono_operando)
        if nombre_app=="Volver al menu principal":
            cumple=True
        else:
            cumple=telefono_operando.apps["AppStore"].descargar_app(nombre_app)
            if cumple=="NO":
                cumple=True

#Menú principal - opción 2 - menú Abrir app - app AppStore - opción 2

def opcion2_menu_appstore(telefono_operando):
    telefono_operando.apps["AppStore"].mostrar_apps_instaladas()

#Menú principal - opción 2 - menú Abrir app - app AppStore - opción 3

def menu_opcion3_appstore(telefono_operando):
    texto_appstore = "\nSeleccione la aplicación que desea eliminar: "
    opciones_appstore = list(telefono_operando.apps["AppStore"].apps_instaladas.keys())
    opciones_appstore.append("Volver al menu principal")
    menu_appstore = Menu(opciones_appstore,texto_appstore)
    opcion_app=menu_appstore.pedir_opcion()
    app=opciones_appstore[int(opcion_app)-1]
    return app

def opcion3_menu_appstore(telefono_operando):
    if len(telefono_operando.apps["AppStore"].apps_instaladas)>0:
        cumple=False
        while not cumple:
            nombre_app=menu_opcion3_appstore(telefono_operando)
            if nombre_app=="Volver al menu principal":
                cumple=True
            else:
                cumple=telefono_operando.apps["AppStore"].eliminar_app(nombre_app)
    else:
        print("No tiene ninguna aplicación extra en su teléfono para eliminar")

#Menú principal - opción 4 - menú Abrir app - App AppStore - main

def opcion_abrir_app_appstore(telefono_operando):
    sigue=True
    while sigue:
        opcion_appstore=menuAppStore(telefono_operando)
        if len(telefono_operando.apps["AppStore"].apps_instaladas)>0:
            match opcion_appstore:
                case "1":
                    opcion1_menu_appstore(telefono_operando)
                case "2":
                    opcion2_menu_appstore(telefono_operando)
                case "3":
                    opcion3_menu_appstore(telefono_operando)
                case "4":
                    sigue=False
        else:
            match opcion_appstore:
                case "1":
                    opcion1_menu_appstore(telefono_operando)
                case "2":
                    opcion2_menu_appstore(telefono_operando)
                case "3":
                    sigue=False