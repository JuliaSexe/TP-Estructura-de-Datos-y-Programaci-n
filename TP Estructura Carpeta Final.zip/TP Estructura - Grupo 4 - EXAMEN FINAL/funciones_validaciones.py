#import
import re
from Class_Telefono import *

##############################################
#FUNCIONES DE VALIDACIONES
##############################################

#Menú principal - opción 1 - validar Nombre

def validarNombre(nombre:str): #Valida que el nombre del teléfono sea un string de longitud mayor o igual que 1 (esto es lo que realmente te permite hacer el teléfono con el nombre, pude ser solo un espacio vacío
    return len(nombre)>=1

#Menú principal - opción 1 - validar Número de teléfono

def validarNumeroTelefono(numero:str): ##Valida que el número de teléfono esté formado por dígitos numéricos y su longitud sea 10. Consideramos que la condición es que su longitud sea 10. Devuelve True si es válido, False en caso contrario
    return (numero.isdigit()) and len(numero) == 10

#Menú principal - opción 1 - validar repetición de Número de teléfono

def validarRepeticionTelefono(numero_telefono:str): ##Recibe el número de teléfono como parámetro y valida que no haya dos números iguales. No se pueden instanciar dos teléfonos con el mismo número
        if Telefono.telefonos:
            for id_telefono,telefono_obj in Telefono.telefonos.items(): ##Recorre los valores de la lista con diccionarios de teléfonos de la class Teléfono y sale de la función si encuentra algún número de teléfono igual al que se le pasa como parámetro
                if numero_telefono == telefono_obj.num_telefono:
                    return False
            return True
        else:
            return True
        
#Menú principal - opción 1 - validar Código de desbloqueo
        
def validarCodigo(codigo:str): ##Valida el código de desbloqueo. Se fija que esté formado por dígitos numéricos y que su longitud sea 4. Consideramos que los códigos de todos los teléfonos pueden ser de 4 dígitos. Devuelve True si es válido, False en caso contrario
    return len(codigo) == 4 and codigo.isdigit()

#Menú principal - opción 2 - validar Email

def validarEmail(email:str):
    patron = r"^(?=.{1,254}$)(?=.{1,64}@.{1,255}$)([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})$"
    
    # Verificar si el email coincide con el patrón
    if re.match(patron, email):
        return True
    else:
        return False

#Menú principal - opción 2 - validar Asunto

def validarAsunto(asunto):
    if not asunto or asunto.isspace():
        asunto="(sin asunto)"
        return asunto
    elif len(asunto) > 100:
        print("El asunto es demasiado largo (máximo 100 caracteres)")
        return False
    return True

#Menú principal - opción 2 - validar Contenido

def validarContenido(contenido):
    if not contenido:
        print("El contenido no puede estar vacío")
        return False
    elif len(contenido) > 1000:
        print("El contenido es demasiado largo (máximo 1000 caracteres)")
        return False
    return True