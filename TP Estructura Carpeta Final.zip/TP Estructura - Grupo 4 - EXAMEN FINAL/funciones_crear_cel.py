#import
from Class_Telefono import *
from Class_Menu import *
from funciones_operacionesCSV import *
from funciones_pedido_inputs import *

#Menú principal - opción 1

def opcion_crear_nuevo_tel(): #Muestra el menú de la opción 1 del menú principal que es crear un nuevo teléfono y devuelve el objeto instanciado
    opcion_nombre=menuNombre()
    telefono=Telefono(asignarId(),pedirNombre(opcion_nombre),menuModelo(),menuAlmacenamiento(),pedirNumero(),pedirCodigo()) #en esta línea se llama a las funciones de pedido y dentro de ellas a las validaciones de cada atributo
    print(f"\nSu teléfono con ID {telefono.id} ha sido creado con éxito")
    return telefono
    
#Menú principal - opción 1 - menú Nombre

def menuNombre(): #Muestra el menú para elegir si quiere o no cambiar el nombre por default del teléfono
    texto_nombre = "\nEl nombre de su teléfono por default es 'Mi teléfono', quiere cambiar el nombre?:\n"
    opciones = ['Si','No']
    menu_nombre=Menu(opciones,texto_nombre)
    opcion_nombre=menu_nombre.pedir_opcion()
    return opcion_nombre

#Menú principal - opción 1 - menú Modelo

def menuModelo(): ##Muestra el menú para conseguir el modelo elegido por el usuario. Devuelve la opción seleccionada ya validada. 
    texto_modelo = '\nPara poder crear un teléfono debe elegir el modelo:\n'
    modelos = [modelo['Nombre'] for modelo in Telefono.modelos_disponibles.values()]
    menu_modelo = Menu(modelos, texto_modelo)
    opcion_modelo = menu_modelo.pedir_opcion()
    return opcion_modelo

#Menú principal - opción 1 - menú Almacenamiento

def menuAlmacenamiento(): ##Muestra el menú para elegir el almacenamiento por el usuario. Todos los modelos tienen las mismas posibilidades. Devuelve la opción ya validada
    texto_almacenamiento = '\nAhora debe elegir el almacenamiento de su teléfono:\n'
    opciones_almacenamiento = Telefono.almacenamientos_disponibles
    menu_almacenamiento = Menu(opciones_almacenamiento, texto_almacenamiento)
    opcion_almacenamiento = menu_almacenamiento.pedir_opcion()
    return opcion_almacenamiento

#Menú principal - opción 1 - asignar ID

def asignarId(): ##Asigna un id a partir de 100000. El último asignado es el id más grande y va sumando uno a partir de ese.
    telefonos=leerCSV()
    if telefonos == None: 
        return 100000
    else: 
        ids = [int(telefono['id']) for telefono in telefonos] #Recorre la lista con diccionarios y para cada diccionario busca la clave 'id' y pasa el valor a int para posteriormente pasarlos a una lista y encontrar el valor máximo y sumarle 1
        return max(ids)+1