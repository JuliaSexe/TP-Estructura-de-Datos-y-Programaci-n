from Class_Aplicacion import *

class Configuracion(Aplicacion):
    def __init__(self):
        super().__init__('Configuracion')