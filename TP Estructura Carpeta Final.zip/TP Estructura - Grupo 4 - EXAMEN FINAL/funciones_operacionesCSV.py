#import
import ast #Llamamos a ast.literal_eval() pasando el string, y esto lo convierte en un objeto Python (en este caso, un diccionario).
import datetime
from Class_Exportador import *
from Class_Telefono import *
from Class_Aplicacion import *

##############################################
#FUNCIONES DE OPERACIONES CON CSV
##############################################


def escribir_csv_unico(telefono): #Función que escribe el archivo CSV con los teléfonos instanciados, utiliza la clase ExportadorTelefono
    exportador=ExportadorTelefono("Teléfonos.csv")
    exportador.exportar_unico(telefono)

def escribir_csv_todos():
    exportador=ExportadorTelefono("Teléfonos.csv")
    exportador.exportar_todos(Telefono.telefonos)

def leerCSV(): #Función que lee el archivo CSV
    exportador=ExportadorTelefono("Teléfonos.csv")
    return exportador.leer()

def cargarTelefonosdeCSV():
    telefonos_csv=leerCSV()
    if telefonos_csv:
        for telefono in telefonos_csv:
            Telefono(int(telefono["id"]),telefono["nombre"],telefono["modelo"],telefono["sist_operativo"],telefono["version"],telefono["memoria_ram"],telefono["almacenamiento"],telefono["num_telefono"],telefono["codigo_desbloqueo"],telefono["red_movil"],telefono["internet"],telefono["prendido"] in ["True", True],telefono["desbloqueado"] in ["True", True],instanciar_apps_csv(telefono))
    
def registroDispositivosCentral(central):
    if Telefono.telefonos:
        for telefono in Telefono.telefonos.keys():
            if telefono not in central.dispositivos_registrados:
                central.registrar_dispositivo(str(telefono))

def registroUnDispositivoCentral(telefono,central):
    if str(telefono.id) not in central.dispositivos_registrados:
        central.registrar_dispositivo(str(telefono.id))

def desactivarDispositivosCentral(central):
    if Telefono.telefonos:
        for telefono in Telefono.telefonos.keys():
            central.actualizar_estado_dispositivo(telefono, False, "desconectado")

def instanciar_apps_csv(telefono):
    apps_basicas = {'Telefono': None, 'Contactos': None, 'Mensajes': None, 'Email': None, 'AppStore': None,'Configuracion': None}
    dict_str=telefono["apps"]
    dict=ast.literal_eval(dict_str)
    for nombre,valor in dict.items():
        if nombre=="Telefono":
            apps_basicas[nombre]=AppTelefono(valor[1],valor[2])
        elif nombre=="Contactos":
            apps_basicas[nombre]=Contacto(valor[1])
        elif nombre=="Mensajes":
            apps_basicas[nombre]=Mensajes()
        elif nombre=="Email":
            apps_basicas[nombre]=AppEmail(valor[1],valor[2],deque(Email(valor[0],valor[1],valor[2],valor[3],datetime.fromisoformat(valor[4]),valor[5]) for valor in valor[3]),[Email(valor[0],valor[1],valor[2],valor[3],datetime.fromisoformat(valor[4]),valor[5]) for valor in valor[4]])
        elif nombre=="AppStore":
            dict_appstore={}
            for nombre_app in valor[1]:
                if nombre_app=="Calculadora":
                    dict_appstore[nombre_app]=Calculadora()
                else:
                    dict_appstore[nombre_app]=NuevaAplicacion(nombre_app)
            apps_basicas[nombre]=AppStore(dict_appstore)
        elif nombre=="Configuracion":
            apps_basicas[nombre]=Configuracion()
        else:
            apps_basicas[nombre]=Aplicacion(nombre)
    return apps_basicas