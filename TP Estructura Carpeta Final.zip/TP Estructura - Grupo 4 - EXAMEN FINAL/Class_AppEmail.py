from collections import deque
from Class_Email import *
from Class_Aplicacion import *

class AppEmail(Aplicacion):
    def __init__(self,direccion_remitente=None,agenda_emails=None,bandeja_x_noleido=None,bandeja_x_fecha=None):
        super().__init__('Email')
        self.direccion_remitente=direccion_remitente
        self.agenda_emails=agenda_emails if agenda_emails is not None else set() #Utilizamos un set porque asegura que no haya duplicados y no necesitamos el orden
        self.bandeja_x_noleido=bandeja_x_noleido if bandeja_x_noleido is not None else deque()
        self.bandeja_x_fecha=bandeja_x_fecha if bandeja_x_fecha is not None else []
    
    def mandar_mail(self,destinatario,asunto,contenido):
        nuevo_mail=Email(self.direccion_remitente,destinatario,asunto,contenido)
        print(f"Correo enviado a {destinatario} con el asunto: {asunto}")
    
    def agregarEmailAgenda(self,direccion_email):
        self.agenda_emails.add(direccion_email)

    def agregar_mail_recibido(self,remitente,asunto,contenido,fecha=None):
        nuevo_mail=Email(remitente,self.direccion_remitente,asunto,contenido,fecha)
        
        #Inserta en bandeja por no leido. Usa append left porque actúa como una pila y hay prioridad por ver los no leídos primero
        self.bandeja_x_noleido.appendleft(nuevo_mail)
        
        #Inserta en bandeja por fecha (los primeros mails son los mas antiguos)
        index = next((i for i, e in enumerate(self.bandeja_x_fecha) if e.fecha > nuevo_mail.fecha), len(self.bandeja_x_fecha))
        self.bandeja_x_fecha.insert(index, nuevo_mail)
    
    def marcar_mail_leido(self,mail:Email):
        mail.marcar_como_leido()
        if mail in self.bandeja_x_noleido:
            self.bandeja_x_noleido.remove(mail)
            self.bandeja_x_noleido.append(mail)
    
    def obtener_bandeja_noleido(self):
        return list(self.bandeja_x_noleido)
    
    def obtener_bandeja_fecha(self):
        return self.bandeja_x_fecha