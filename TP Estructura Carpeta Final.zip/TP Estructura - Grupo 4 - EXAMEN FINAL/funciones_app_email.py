#import
from itertools import islice
from Class_Menu import *
from funciones_pedido_inputs import *

#Menú principal - opción 2 - menú Abrir app - app Email

def menuEmail(telefono_operando):
    texto_email = "\nElija la opción que desee: "
    if telefono_operando.apps["Email"].direccion_remitente==None:
        opciones_email = {"1":"Registrar dirección de e-mail personal","2":"Ver e-mails por 'no leídos primeros'","3":"Ver e-mails 'por fecha'","4":"Volver al menú principal"}
    else:
        opciones_email = {"1":"Mandar un e-mail","2":"Ver e-mails por 'no leídos primeros'","3":"Ver e-mails 'por fecha'","4":"Volver al menú principal"}
    menu_email = Menu(opciones_email,texto_email)
    opcion_email=menu_email.pedir_opcion()
    return opcion_email

#Menú principal - opción 2 - menú Abrir app - app Email - opción 1

def opcion1_menu_email(telefono_operando):
    if telefono_operando.apps["Email"].direccion_remitente==None:
        email_personal=pedirEmailPersonal()
        telefono_operando.apps["Email"].direccion_remitente=email_personal
        print("Ha registrado satisfactoriamente su correo electrónico en la app")
    else:
        print(f"Su correo electrónico ya fue registrado y es {telefono_operando.apps["Email"].direccion_remitente}")
        #Asumimos que nuestra app email solo permite registrar una unica vez el correo electronico

#Menú principal - opción 2 - menú Abrir app - app Email - opción 2

def opcion2_menu_email(telefono_operando):
    if no_hay_email_registrado(telefono_operando):
        return

    print("\nEsta es su agenda de contactos:")
    if agenda_email_vacia(telefono_operando):
        gestionar_envio_a_email_nuevo(telefono_operando)
    else:
        gestionar_envio_a_contacto_email(telefono_operando)

def no_hay_email_registrado(telefono_operando):
    if telefono_operando.apps["Email"].direccion_remitente == None:
        print("Primero debe registrar su email con la opción 1")
        return True
    return False

def agenda_email_vacia(telefono_operando):
    return len(telefono_operando.apps["Email"].agenda_emails) == 0

def gestionar_envio_a_email_nuevo(telefono_operando):
    print("Su agenda de emails se encuentra vacía. Ingrese la dirección de email a la que desea enviar y quedará registrada automáticamente en su agenda.")
    email_a_mandar = pedirEmailParaEnviar()
    telefono_operando.apps["Email"].agregarEmailAgenda(email_a_mandar)
    asunto, contenido = obtener_asunto_y_contenido()
    telefono_operando.apps["Email"].mandar_mail(email_a_mandar, asunto, contenido)
    gestionar_email_recibido(telefono_operando, email_a_mandar, asunto, contenido)

def gestionar_envio_a_contacto_email(telefono_operando):
    texto_mandar_mail = "\nElija el contacto al que desea mandarle mail:"
    opciones_mails = list(telefono_operando.apps["Email"].agenda_emails)
    opciones_mails.append("Quiero mandar el email a otro destinatario que no está en mi agenda")

    menu_mails = Menu(opciones_mails, texto_mandar_mail)
    opcion_mail = menu_mails.pedir_opcion()
    email_a_mandar = opciones_mails[int(opcion_mail) - 1]

    if email_a_mandar != "Quiero mandar el email a otro destinatario que no está en mi agenda":
        asunto, contenido = obtener_asunto_y_contenido()
        telefono_operando.apps["Email"].mandar_mail(email_a_mandar, asunto, contenido)
    else:
        gestionar_envio_a_email_nuevo(telefono_operando)

    gestionar_email_recibido(telefono_operando, email_a_mandar, asunto, contenido)

def obtener_asunto_y_contenido():
    asunto = pedirAsunto()
    contenido = pedirContenido()
    return asunto, contenido

def gestionar_email_recibido(telefono_operando, email_a_mandar, asunto, contenido):
    if email_a_mandar == telefono_operando.apps["Email"].direccion_remitente:
        telefono_operando.apps["Email"].agregar_mail_recibido(email_a_mandar, asunto, contenido, fecha=None)
    else:
        for telefono in Telefono.telefonos.values():
            if telefono.apps["Email"].direccion_remitente == email_a_mandar:
                telefono.apps["Email"].agregar_mail_recibido(
                    telefono_operando.apps["Email"].direccion_remitente, asunto, contenido, fecha=None)

#Menú principal - opción 2 - menú Abrir app - app Email - opción 3

def opcion3_menu_email(telefono_operando):
    if len(telefono_operando.apps["Email"].obtener_bandeja_noleido())>0:
        texto_email = "\nElija el e-mail que desea ver: "
        opciones_email = telefono_operando.apps["Email"].obtener_bandeja_noleido()
        menu_email = Menu(opciones_email,texto_email)
        opcion_email=menu_email.pedir_opcion()
        email_a_ver = next(islice(telefono_operando.apps["Email"].bandeja_x_noleido, int(opcion_email)-1, int(opcion_email)-1 + 1))
        print(email_a_ver.ver_contenido())
        telefono_operando.apps["Email"].marcar_mail_leido(next(islice(telefono_operando.apps["Email"].bandeja_x_noleido, int(opcion_email)-1, int(opcion_email)-1 + 1)))
    else:
        print("Su bandeja de emails recibidos está vacía")

#Menú principal - opción 2 - menú Abrir app - app Email - opción 4

def opcion4_menu_email(telefono_operando):
    if len(telefono_operando.apps["Email"].obtener_bandeja_fecha())>0:
        texto_email = "\nElija el e-mail que desea ver: "
        opciones_email = telefono_operando.apps["Email"].obtener_bandeja_fecha()
        menu_email = Menu(opciones_email,texto_email)
        opcion_email=menu_email.pedir_opcion()
        email_a_ver=telefono_operando.apps["Email"].bandeja_x_fecha[int(opcion_email)-1]
        print(email_a_ver.ver_contenido())
        if not email_a_ver.leido:
            telefono_operando.apps["Email"].marcar_mail_leido(telefono_operando.apps["Email"].bandeja_x_fecha[int(opcion_email)-1])
    else:
        print("Su bandeja de emails recibidos está vacía")

#Menú principal - opción 4 - menú Abrir app - App Email - main

def opcion_abrir_app_email(telefono_operando):
    sigue=True
    while sigue:
        opcion_email=menuEmail(telefono_operando)
        if telefono_operando.apps["Email"].direccion_remitente==None:
            match opcion_email:
                case "1":
                    opcion1_menu_email(telefono_operando)
                case "2":
                    opcion3_menu_email(telefono_operando)
                case "3":
                    opcion4_menu_email(telefono_operando)
                case "4":
                    sigue=False
        else:
            match opcion_email:
                case "1":
                    opcion2_menu_email(telefono_operando)
                case "2":
                    opcion3_menu_email(telefono_operando)
                case "3":
                    opcion4_menu_email(telefono_operando)
                case "4":
                    sigue=False