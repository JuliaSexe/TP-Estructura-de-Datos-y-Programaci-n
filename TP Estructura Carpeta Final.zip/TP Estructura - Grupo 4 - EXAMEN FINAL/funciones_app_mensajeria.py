#import
from Class_Menu import *
from funciones_pedido_inputs import *

#Menú principal - opción 2 - menú Abrir app - app Mensajeria SMS

def menuMensajeria(telefono_operando):
    texto_mensajes="\nElija la opción que desee: "
    if all(not valor for valor in telefono_operando.apps["Mensajes"].mensajes_enviados.values()) and all(not valor for valor in telefono_operando.apps["Mensajes"].mensajes_recibidos.values()):
        opciones_mensajes={"1":"Enviar SMS a un número de destino","2":"Abrir bandeja de entrada","3":"Abrir bandeja de salida","4":"Volver al menú principal"}
    else:
        opciones_mensajes={"1":"Enviar SMS a un número de destino","2":"Abrir bandeja de entrada","3":"Abrir bandeja de salida","4":"Eliminar SMS","5":"Volver al menú principal"}
    menu_mensajes=Menu(opciones_mensajes,texto_mensajes)
    opcion_mensaje=menu_mensajes.pedir_opcion()
    return opcion_mensaje

#Menú principal - opción 2 - menú Abrir app - app Mensajeria SMS - opción 1

def opcion1_menu_mensajeria(telefono_operando, central):
    print("\nEsta es su agenda de contactos: ")

    if no_hay_contactos(telefono_operando):
        gestionar_envio_a_numero_nuevo(telefono_operando, central)
    else:
        gestionar_envio_a_contacto(telefono_operando, central)

def no_hay_contactos(telefono_operando):
    if len(telefono_operando.apps["Contactos"].contactos) == 0:
        print("Su agenda de teléfonos se encuentra vacía. Ingrese el teléfono al que desea mandar mensaje.")
        return True
    return False

def gestionar_envio_a_numero_nuevo(telefono_operando, central):
    numero = pedirNumeroContacto()
    pedirNumYMandarMensaje(telefono_operando, central, numero)

def gestionar_envio_a_contacto(telefono_operando, central):
    texto_mensaje = "\nElija el contacto al que desea mandar mensaje: "
    opciones_contactos = telefono_operando.apps["Contactos"].contactos.copy()
    opciones_contactos.append("Quiero mandar mensaje a otro destinatario que no está en mi agenda")
    menu_mensaje = Menu(opciones_contactos, texto_mensaje)
    opcion_contacto = menu_mensaje.pedir_opcion()

    if es_contacto_existente(opciones_contactos, opcion_contacto):
        gestionar_envio_a_numero_de_contacto(telefono_operando, central, opcion_contacto)
    else:
        gestionar_envio_a_numero_nuevo(telefono_operando, central)

def es_contacto_existente(opciones_contactos, opcion_contacto):
    return opciones_contactos[int(opcion_contacto) - 1] != "Quiero mandar mensaje a otro destinatario que no está en mi agenda"

def gestionar_envio_a_numero_de_contacto(telefono_operando, central, opcion_contacto):
    contacto = telefono_operando.apps["Contactos"].contactos[int(opcion_contacto) - 1]

    if len(contacto["numeros"]) == 1:
        numero = contacto["numeros"][0]
        pedirNumYMandarMensaje(telefono_operando, central, numero)
    else:
        gestionar_envio_a_numero_seleccionado(contacto, telefono_operando, central)

def gestionar_envio_a_numero_seleccionado(contacto, telefono_operando, central):

    texto_elegir_numero = "\nElija qué número de su contacto desea mandar mensaje: "
    menu_numeros = Menu(contacto["numeros"], texto_elegir_numero)
    opcion_numero = menu_numeros.pedir_opcion()
    numero = contacto["numeros"][int(opcion_numero) - 1]
    pedirNumYMandarMensaje(telefono_operando, central, numero)

#Menú principal - opción 2 - menú Abrir app - app Mensajeria SMS - opción 2

def opcion2_menu_mensajeria(telefono_operando):
    telefono_operando.apps["Mensajes"].ver_bandeja_entrada(str(telefono_operando.id))

#Menú principal - opción 2 - menú Abrir app - app Mensajeria SMS - opción 3

def opcion3_menu_mensajeria(telefono_operando):
    telefono_operando.apps["Mensajes"].ver_historial_enviados(str(telefono_operando.id))

#Menú principal - opción 2 - menú Abrir app - app Mensajeria SMS - opción 4

def opcion4_menu_mensajeria(telefono_operando):
    tipo=pedirTipoMensaje()
    mensaje_indice=pedirMensajeEliminar(telefono_operando,tipo)
    if mensaje_indice!=None:
        telefono_operando.apps["Mensajes"].eliminar_mensaje(tipo,str(telefono_operando.id),mensaje_indice)

#Menú principal - opción 2 - pedir número y mandar mensaje

def pedirNumYMandarMensaje(telefono_operando,central,numero):
    tel=None
    for telefono in Telefono.telefonos.values():
        if telefono.num_telefono==numero:
            tel=telefono
    if tel==None:
        print("Error: está intentando contactar a un dispositivo no registrado")
    else:
        telefono_operando.apps["Mensajes"].enviar_mensajes(str(telefono_operando.id),str(tel.id), pedirContenido(), central,'pendiente')

#Menú principal - opción 2 - menú Abrir app - App Mensajería - main

def opcion_abrir_app_mensajeria(telefono_operando,central):
    sigue=True
    while sigue:
        opcion_mensajeria=menuMensajeria(telefono_operando)
        if  all(not valor for valor in telefono_operando.apps["Mensajes"].mensajes_enviados.values()) and all(not valor for valor in telefono_operando.apps["Mensajes"].mensajes_recibidos.values()):
            match opcion_mensajeria:
                case '1':
                    opcion1_menu_mensajeria(telefono_operando,central)
                case "2":
                    opcion2_menu_mensajeria(telefono_operando)
                case "3":
                    opcion3_menu_mensajeria(telefono_operando)
                case "4":
                    sigue=False
        else:
            match opcion_mensajeria:
                case '1':
                    opcion1_menu_mensajeria(telefono_operando,central)
                case "2":
                    opcion2_menu_mensajeria(telefono_operando)
                case "3":
                    opcion3_menu_mensajeria(telefono_operando)
                case "4":
                    opcion4_menu_mensajeria(telefono_operando)
                case "5":
                    sigue=False