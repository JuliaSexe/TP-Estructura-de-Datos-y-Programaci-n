import random

def elegir_palabra():
    palabras = ["python", "programacion", "estructura"]
    return random.choice(palabras)

def mostrar_estado(palabra, letras_ingresadas):
    estado = ""
    for letra in palabra:
        if letra in letras_ingresadas:
            estado += letra + " "
        else:
            estado += "_ "
    return estado.strip()

def es_letra_valida(letra):
    return letra.isalpha() and len(letra) == 1

def jugar_hangman():
    print("¡Bienvenido al juego del Ahorcado!")
    palabra_secreta = elegir_palabra()
    letras_ingresadas = set()
    intentos = 5
    juego_terminado = False

    while not juego_terminado:
        print("\nPalabra a adivinar:", mostrar_estado(palabra_secreta, letras_ingresadas))
        print("Intentos restantes:", intentos)
        print("Letras ingresadas:", " ".join(sorted(letras_ingresadas)))

        letra = input("Adivina una letra: ").lower()

        if not es_letra_valida(letra):
            print("Entrada no válida. Asegúrate de ingresar solo una letra.")
            continue

        if letra in letras_ingresadas:
            print("Ya ingresaste esa letra. Intenta con otra.")
            continue

        if letra in palabra_secreta:
            letras_ingresadas.add(letra)
            print(f"¡Correcto! La letra '{letra}' está en la palabra.")

        else:
            letras_ingresadas.add(letra)
            intentos -= 1
            print(f"Incorrecto. La letra '{letra}' no está en la palabra.")

        if all(letra in letras_ingresadas for letra in palabra_secreta):
            print(f"¡Felicidades! Has adivinado la palabra: {palabra_secreta}")
            juego_terminado = True

        if intentos == 0:
            print(f"¡Se acabaron los intentos! La palabra era: {palabra_secreta}")
            juego_terminado = True