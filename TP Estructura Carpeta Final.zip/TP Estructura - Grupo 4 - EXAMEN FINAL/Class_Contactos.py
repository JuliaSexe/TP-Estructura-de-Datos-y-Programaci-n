from Class_Aplicacion import *

class Contacto(Aplicacion): 
    def __init__(self,contactos=None):
        super().__init__('Contactos')
        self.contactos= contactos if contactos is not None else [] ##Usamos una lista de diccionarios con dos elementos donde la clave del primero es "nombre" y el valor es el nombre del contacto y la clave del segundo es "telefonos" y el valor es una lista con los numeros de telefono del contacto
    
    def agendar_nuevo_contacto(self, nombre: str, numero: str): 
        self.contactos.append({'nombre': nombre, 'numeros': [numero]})
        print(f"El contacto {nombre} con número {numero} ha sido agendado con exito")
    
    def ver_lista_contactos(self):
        resultado = "\nSu agenda tiene los siguientes contactos:\n"
        for contacto in self.contactos:
            numeros = ", ".join(contacto['numeros'])  # Unimos los números con coma
            resultado += f"Nombre: {contacto['nombre']} - Números: {numeros}\n"
        
        return resultado