from datetime import datetime
from Class_Exportador import Exportador

class Central:
    def __init__(self):
        self.dispositivos_registrados = {}  # id: {activo: bool, red: str}
        self.mensajes_pendientes = {}  # id_receptor: [mensajes]
        self.registro_comunicaciones = []
        self.exportador = Exportador("registro_comunicaciones.csv")
        self.id_mensaje_contador = self.cargar_id_mensaje_contador()

    def registrar_dispositivo(self, id_dispositivo): ##regustra un telefono en la central
        if id_dispositivo not in self.dispositivos_registrados:
            self.dispositivos_registrados[id_dispositivo] = {"activo": False, "red": "desconectado"}
            self.registrar_evento("registro_dispositivo", id_dispositivo)
            return True
        return False
    
    def eliminar_dispositivo(self, id_dispositivo): ##elimina un telefono de la central --> no se isa pero si se desea se podria agregar
        if id_dispositivo in self.dispositivos_registrados:
            del self.dispositivos_registrados[id_dispositivo]
            self.registrar_evento("eliminacion_dispositivo", id_dispositivo)
            return True
        return False
    
    def actualizar_estado_dispositivo(self, id_dispositivo, activo: bool, red: str): ##actualiza el estado de un dispositivo
        if id_dispositivo in self.dispositivos_registrados:
            self.dispositivos_registrados[id_dispositivo].update({"activo": activo,"red": red}) 
            self.registrar_evento("actualizacion_estado", id_dispositivo)
            return True
        return False

    def verificar_disponibilidad(self, id_dispositivo): ##verifica disponibilidas del telefono
        if id_dispositivo not in self.dispositivos_registrados:
            return (False, "Dispositivo no registrado")
        estado = self.dispositivos_registrados[id_dispositivo]
        if not estado["activo"]:
            return (False, "Dispositivo inactivo")
        if estado["red"] != "conectado":
            return (False, "Sin conexión a la red")
        return (True, "Dispositivo disponible")
    
    def solicitar_comunicacion(self, id_emisor, id_receptor, tipo): ##solicia comunicacion, registra entregado si esta disponible el receptor, y pendiente si no
        (emisor_disponible, mensj_emisor) = self.verificar_disponibilidad(id_emisor)
        if not emisor_disponible:
            return f'Error: Telefono emisor no disponible: {mensj_emisor}',None
        (receptor_disponible, mensj_receptor) = self.verificar_disponibilidad(id_receptor)
        id_comunicacion = self.generar_id_comunicacion(tipo)
        
        if tipo=="mensaje":
            if receptor_disponible:
                estado = "entregado" 
            else:
                estado = "pendiente"
        
        elif tipo=="llamada":
            if receptor_disponible:
                estado = "establecida" 
            else:
                estado = "no establecida"
                
        comunicacion = {"id_comunicacion": id_comunicacion, "tipo": tipo, "id_emisor": id_emisor, "id_receptor": id_receptor, "hora": datetime.now(), "estado": estado}
        
        self.registrar_evento(tipo, None, comunicacion)
        
        # Si es un mensaje y el receptor no está disponible, almacenar como pendiente
        if tipo == "mensaje" and not receptor_disponible:
            if id_receptor not in self.mensajes_pendientes:
                self.mensajes_pendientes[id_receptor] = []
            self.mensajes_pendientes[id_receptor].append(comunicacion)
            
        return comunicacion,estado
    
    def obtener_mensajes_pendientes(self, id_receptor): 
        return self.mensajes_pendientes.get(id_receptor, [])
    
    def confirmar_entrega_mensaje(self, id_comunicacion): ##si el mensaje estaba pendiente y se recibe 
        for id_receptor, mensajes in self.mensajes_pendientes.items():
            for mensaje in mensajes:
                if mensaje["id_comunicacion"] == id_comunicacion:
                    mensaje["estado"] = "entregado"
                    self.registrar_evento("confirmacion_entrega", None, mensaje)
                    mensajes.remove(mensaje)
                    return True
        return False
    
    def registrar_evento(self, tipo, id_dispositivo = None, datos_adicionales = None): ##regustra los eventos
        evento = {"tipo": tipo, "hora": datetime.now().strftime('%Y-%m-%d %H:%M:%S'), "id_dispositivo": id_dispositivo if id_dispositivo else '--', "id_comunicacion": '--', "emisor": '--', "receptor": '--', "estado": '--'}
        
        if datos_adicionales and tipo in ['mensaje', 'llamada', 'confirmacion_entrega']:
            evento.update({"id_comunicacion": datos_adicionales["id_comunicacion"],"emisor": datos_adicionales["id_emisor"],"receptor": datos_adicionales["id_receptor"],"estado": datos_adicionales["estado"]})
            
        self.registro_comunicaciones.append(evento)
        self.exportador.exportar([evento])
    
    def cargar_id_mensaje_contador(self): 
        ##Carga el último ID desde el archivo de registro de comunicaciones
        datos = self.exportador.leer()
        if datos:
            ids_com = []
            for fila in datos: 
                if fila['id_comunicacion'] and fila['id_comunicacion'].isdigit():
                    ids_com.append(int(fila["id_comunicacion"]))
            if ids_com: 
                return max(ids_com) + 1
        return 1 ##devuelve 1 si no hay maximo

    def generar_id_comunicacion(self, tipo):
        id_mensaje = self.id_mensaje_contador
        self.id_mensaje_contador += 1
        return str(id_mensaje)  # Usar el número como string sin prefijo