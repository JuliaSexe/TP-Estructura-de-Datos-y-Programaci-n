from Class_Aplicacion import *

class Calculadora(Aplicacion):
    def __init__(self):
        #diccionario para almacenar las operaciones disponibles
        self.operaciones = {
            '+': self.sumar,
            '-': self.restar,
            '*': self.multiplicar,
            '/': self.dividir
        }
        
        #conjunto para operadores válidos
        self.operadores_validos = {'+', '-', '*', '/'}
    
    def sumar(self, a, b):
        return a + b
    
    def restar(self, a, b):
        return a - b
    
    def multiplicar(self, a, b):
        return a * b
    
    def dividir(self, a, b):
        if b == 0:
            raise ValueError("No se puede dividir por cero")
        return a / b
    
    def calcular(self, num1, operador, num2):
        try:
            #validar el operador utilizando el conjunto
            if operador not in self.operadores_validos:
                raise ValueError("Operador no válido")
            
            #realiza la operación usando el diccionario de funciones
            resultado = self.operaciones[operador](num1, num2)
        
            return resultado
            
        except Exception as e:
            return f"Error: {str(e)}"