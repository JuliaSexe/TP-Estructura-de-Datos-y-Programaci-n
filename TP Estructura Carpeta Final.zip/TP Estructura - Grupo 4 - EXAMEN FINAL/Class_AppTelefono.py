from datetime import datetime
from Class_Aplicacion import *

class AppTelefono(Aplicacion):
    def __init__(self,historial_llamadas=None,llamada_en_curso=False):
        super().__init__("Telefono")
        self.historial_llamadas=historial_llamadas if historial_llamadas is not None else []
        self.llamada_en_curso=llamada_en_curso
    
    def verificar_hay_llamada(self):
        if self.llamada_en_curso:
            return True
        else:
            return False
    
    def agregarAlHistorial(self,nombre_contacto,numeros_contacto):
        fecha=datetime.now().isoformat()
        self.historial_llamadas.append((nombre_contacto,numeros_contacto,fecha))
    
    def llamar(self,nombre_contacto,numeros_contacto):
        self.llamada_en_curso=True
        self.agregarAlHistorial(nombre_contacto,numeros_contacto)
        print(f"\nLlamada en curso a {nombre_contacto} con numero {numeros_contacto}")
    
    def cortarParaApagar(self):
        if self.llamada_en_curso:
            print("Su llamada ha sido finalizada para poder apagar el teléfono")
            self.llamada_en_curso=False
    
    def terminar_llamada(self):
        if self.llamada_en_curso:
            print("La llamada ha sido terminada.")
            self.llamada_en_curso = False  # Resetea el estado de la llamada en curso
        else:
            print("No hay ninguna llamada en curso para terminar.")
    
    #el metodo recibir llamada ocurre automaticamente cuando un telefono llama a otro, es decir, si el telefono que recibe la llamada no está ocupado, recibe automáticamente la llamada
    def recibir_llamada(self, numero_llamante):
        if self.llamada_en_curso:
            print("Ya hay una llamada en curso. No puede recibir otra.")
        else:
            print(f"Recibiendo una llamada de {numero_llamante}...")
            self.llamada_en_curso = True
    
    def ver_historial_llamadas(self):
        if not self.historial_llamadas:
            print("El historial de llamadas está vacío.")
            return
        
        print("Historial de Llamadas:")
        for i, (nombre_contacto, numeros_contacto, fecha) in enumerate(self.historial_llamadas, start=1):
            print(f"{i}. Contacto: {nombre_contacto}, Número: {numeros_contacto}, Fecha: {fecha}")