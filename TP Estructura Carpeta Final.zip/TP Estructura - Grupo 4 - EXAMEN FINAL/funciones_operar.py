#import
from Class_Menu import *
from Class_Telefono import *
from AppAhorcado import *
from Class_AppCalculadora import *
from AppCronometro import *
from AppTrivia import *
from funciones_app_telefono import *
from funciones_app_contactos import *
from funciones_app_mensajeria import *
from funciones_app_email import *
from funciones_app_appstore import *
from funciones_app_configuracion import *

#Menú principal - opción 2 - menú elección teléfono

def menuTelefonosParaOperar():
    texto_telefonos="\nEstos son los teléfonos existentes para operar:\n"
    opciones_telefonos =Telefono.telefonosParaOperar()
    menu_tel_operar=Menu(opciones_telefonos,texto_telefonos)
    opcion_telefono=menu_tel_operar.pedir_opcion()
    id_telefono=opciones_telefonos[int(opcion_telefono)-1][0]
    telefono_operando=Telefono.telefonos.get(id_telefono)
    print(f"\nEl teléfono con el que va a operar tiene las siguientes características:")
    print(telefono_operando)
    return telefono_operando

#Menú principal - opción 2

def ver_si_hay_app_abierta(telefono_operando):
    for app in telefono_operando.apps.values():
        if app.ejecucion==True:
            return True
    return False

def ver_si_existe_app_extra(telefono_operando):
    if len(telefono_operando.apps["AppStore"].apps_instaladas)>0:
        return True
    return False

def menu_operar(telefono_operando):
    opcion_x_estado=None
    texto_operacion = '\nIndique qué operación desea realizar con el teléfono seleccionado: '
    if telefono_operando.prendido==False and telefono_operando.desbloqueado==False:
        operaciones=["Encender el teléfono","Volver al menu principal"]
        opcion_x_estado="1"
    elif telefono_operando.prendido==True and telefono_operando.desbloqueado==False:
        operaciones=["Apagar el teléfono",'Desbloquear el teléfono',"Volver al menu principal"]
        opcion_x_estado="2"
    elif telefono_operando.prendido==True and telefono_operando.desbloqueado==True:
        if ver_si_hay_app_abierta(telefono_operando) and not ver_si_existe_app_extra(telefono_operando):
            operaciones=['Apagar el teléfono', 'Bloquear el teléfono', 'Abrir una aplicación (básica)', 'Cerrar una aplicación (básica)','Volver al menu principal']
            opcion_x_estado="3"
        elif ver_si_hay_app_abierta(telefono_operando) and ver_si_existe_app_extra(telefono_operando):
            operaciones = ['Apagar el teléfono', 'Bloquear el teléfono', 'Abrir una aplicación (básica)', 'Cerrar una aplicación (básica)','Operar una aplicación (no básica)','Volver al menu principal']
            opcion_x_estado="4"
        elif not ver_si_hay_app_abierta(telefono_operando) and ver_si_existe_app_extra(telefono_operando):
            operaciones = ['Apagar el teléfono', 'Bloquear el teléfono', 'Abrir una aplicación (básica)','Operar una aplicación (no básica)','Volver al menu principal']
            opcion_x_estado="5"
        elif not ver_si_hay_app_abierta(telefono_operando) and not ver_si_existe_app_extra(telefono_operando):
            operaciones = ['Apagar el teléfono', 'Bloquear el teléfono', 'Abrir una aplicación (básica)','Volver al menu principal']
            opcion_x_estado="6"
        
    menu_operacion = Menu(operaciones, texto_operacion)
    opcion_operacion = menu_operacion.pedir_opcion()
    return opcion_operacion,opcion_x_estado
    
#Menú principal - opción 2 - menú Abrir app

def menu_abrir_app(telefono):
    titulo_menu="\nQue app quiere abrir?: "
    opciones=telefono.appsParaOperar()
    opciones.append("Volver al menú principal")
    menu_apps=Menu(opciones,titulo_menu)
    opcion_apps=menu_apps.pedir_opcion()
    nombre_app=opciones[int(opcion_apps)-1]
    app_operando=telefono.apps.get(nombre_app)
    if opcion_apps!="7":
        print(f"Va a abrir la app {nombre_app}")
    return app_operando,opcion_apps

#Menú principal - opción 2 - menú Cerrar app

def menu_cerrar_app(telefono):
    titulo_menu="\nQue app quiere cerrar?: "
    opciones=telefono.appsParaOperar()
    opciones.append("Volver al menú principal")
    menu_apps=Menu(opciones,titulo_menu)
    opcion_apps=menu_apps.pedir_opcion()
    nombre_app=opciones[int(opcion_apps)-1]
    app_operando=telefono.apps.get(nombre_app)
    if opcion_apps!="7":
        print(f"Va a cerrar la app {nombre_app}")
    return app_operando,opcion_apps

#Menú principal - opción 2 - opción operar app no básica

def opcion_operar_app_no_basica(telefono_operando):
    texto_apps = "\nElija la aplicación que desea utilizar: "
    opciones_apps = list(telefono_operando.apps["AppStore"].apps_instaladas.keys())
    if len(opciones_apps)>0:
        menu_apps = Menu(opciones_apps,texto_apps)
        opcion_app=menu_apps.pedir_opcion()
        nombre_app=opciones_apps[int(opcion_app)-1]
        app=telefono_operando.apps["AppStore"].apps_instaladas[nombre_app]
        return nombre_app,app
    else:
        print("No hay apps extras para operar. Debe descargar desde la app básica AppStore")
        return None,None

def operar_app_no_basica(nombre_app,app):
    match nombre_app:
        case "Trivia":
            app.ejecucion=True
            juego_trivia_python()
            app.ejecucion=False
        case "Ahorcado":
            app.ejecucion=True
            jugar_hangman()
            app.ejecucion=False
        case "Cronometro":
            app.ejecucion=True
            cronometro()
            app.ejecucion=False
        case "Calculadora":
            app.ejecucion=True
            calculadora(app)
            app.ejecucion=False
        
def calculadora(app):
    
    while True:
        print("\nCalculadora")
        print("1. Realizar operación")
        print("2. Salir")
        
        opcion = input("Seleccione una opción: ")
        
        if opcion == "1":
            try:
                num1 = float(input("Ingrese primer número: "))
                operador = input("Ingrese operador (+, -, *, /): ")
                num2 = float(input("Ingrese segundo número: "))
                
                resultado = app.calcular(num1, operador, num2)
                print(f"Resultado: {resultado}")
                
            except ValueError as e:
                print(f"Error: {str(e)}")
            
        elif opcion == "2":
            print("¡Gracias por usar la calculadora!")
            break
            
        else:
            print("Opción no válida")

#Menú principal - opción 2 - menú Abrir app - main

def opcion_abrir_app(telefono_operando,central):
    sigue=True
    while sigue:
        app,opcion_apps=menu_abrir_app(telefono_operando)
        if opcion_apps!="7":
            telefono_operando.abrirApp(app)
        match opcion_apps:
            case '1':
                opcion_abrir_app_telefono(telefono_operando,central)
            case "2":
                opcion_abrir_app_contacto(telefono_operando)
            case "3":
                opcion_abrir_app_mensajeria(telefono_operando,central)
            case "4":
                opcion_abrir_app_email(telefono_operando)
            case "5":
                opcion_abrir_app_appstore(telefono_operando)
            case "6":
                menuConfiguracion(telefono_operando)
            case "7":
                sigue=False

#Menú principal - opción 2 - menú Cerrar app

def opcion_cerrar_app(telefono_operando):
    sigue=True
    while sigue:
        app,opcion_apps=menu_cerrar_app(telefono_operando)
        if opcion_apps!="7":
            telefono_operando.cerrar_app(app)
        else:
            sigue=False

#Menú principal - opción 2 - main

def opcion_operar(central):
    telefono_operando = menuTelefonosParaOperar()
    sigue = True

    while sigue:
        opcion_elegida, opcion_x_estado = menu_operar(telefono_operando)

        match opcion_x_estado:
            case "1":
                sigue = manejar_estado_1(telefono_operando, central, opcion_elegida)
            case "2":
                sigue = manejar_estado_2(telefono_operando, central, opcion_elegida)
            case "3":
                sigue = manejar_estado_3(telefono_operando, central, opcion_elegida)
            case "4":
                sigue = manejar_estado_4(telefono_operando, central, opcion_elegida)
            case "5":
                sigue = manejar_estado_5(telefono_operando, central, opcion_elegida)
            case "6":
                sigue = manejar_estado_6(telefono_operando, central, opcion_elegida)

def manejar_estado_1(telefono_operando, central, opcion_elegida):
    match opcion_elegida:
        case "1":
            telefono_operando.prenderse()
            central.actualizar_estado_dispositivo(str(telefono_operando.id), True, "conectado")
            telefono_operando.apps["Mensajes"].recibir_mensajes_pendientes(str(telefono_operando.id), central)
        case "2":
            return False
    return True

def manejar_estado_2(telefono_operando, central, opcion_elegida):
    match opcion_elegida:
        case "1":
            telefono_operando.apagarse()
            central.actualizar_estado_dispositivo(str(telefono_operando.id), False, "desconectado")
        case "2":
            telefono_operando.desbloquearse()
        case "3":
            return False
    return True

def manejar_estado_3(telefono_operando, central, opcion_elegida):
    match opcion_elegida:
        case "1":
            telefono_operando.apagarse()
            central.actualizar_estado_dispositivo(str(telefono_operando.id), False, "desconectado")
        case "2":
            telefono_operando.bloquearse()
        case "3":
            if telefono_operando.verificar_prendido_desbloqueado():
                opcion_abrir_app(telefono_operando, central)
        case "4":
            if telefono_operando.verificar_prendido_desbloqueado():
                opcion_cerrar_app(telefono_operando)
        case "5":
            return False
    return True

def manejar_estado_4(telefono_operando, central, opcion_elegida):
    match opcion_elegida:
        case "1":
            telefono_operando.apagarse()
            central.actualizar_estado_dispositivo(str(telefono_operando.id), False, "desconectado")
        case "2":
            telefono_operando.bloquearse()
        case "3":
            if telefono_operando.verificar_prendido_desbloqueado():
                opcion_abrir_app(telefono_operando, central)
        case "4":
            if telefono_operando.verificar_prendido_desbloqueado():
                opcion_cerrar_app(telefono_operando)
        case "5":
            if telefono_operando.verificar_prendido_desbloqueado():
                nombre_app, app = opcion_operar_app_no_basica(telefono_operando)
                if nombre_app and app:
                    operar_app_no_basica(nombre_app, app)
        case "6":
            return False
    return True

def manejar_estado_5(telefono_operando, central, opcion_elegida):
    match opcion_elegida:
        case "1":
            telefono_operando.apagarse()
            central.actualizar_estado_dispositivo(str(telefono_operando.id), False, "desconectado")
        case "2":
            telefono_operando.bloquearse()
        case "3":
            if telefono_operando.verificar_prendido_desbloqueado():
                opcion_abrir_app(telefono_operando, central)
        case "4":
            if telefono_operando.verificar_prendido_desbloqueado():
                nombre_app, app = opcion_operar_app_no_basica(telefono_operando)
                if nombre_app and app:
                    operar_app_no_basica(nombre_app, app)
        case "5":
            return False
    return True

def manejar_estado_6(telefono_operando, central, opcion_elegida):
    match opcion_elegida:
        case "1":
            telefono_operando.apagarse()
            central.actualizar_estado_dispositivo(str(telefono_operando.id), False, "desconectado")
        case "2":
            telefono_operando.bloquearse()
        case "3":
            if telefono_operando.verificar_prendido_desbloqueado():
                opcion_abrir_app(telefono_operando, central)
        case "4":
            return False
    return True