#import
from Class_Telefono import *
from Class_Central import *
from funciones_operacionesCSV import *
from funciones_crear_cel import *
from funciones_operar import *

#Menú principal (3 opciones)
    
def menu_principal(): #Muestra el menú principal del programa con tres opciones y devuelve la opción elegida
    titulo_ppal = "\nMenú principal:"
    if Telefono.telefonos:
        opciones = ['Crear un nuevo télefono', 'Operar sobre un teléfono existente', 'Salir']
    else:
        opciones = ['Crear un nuevo télefono', 'Salir']
    menu_principal=Menu(opciones,titulo_ppal)
    opcion_principal = menu_principal.pedir_opcion()
    return opcion_principal

def inicializar_central():
    cargarTelefonosdeCSV()
    central = Central()
    registroDispositivosCentral(central)
    return central

def manejar_opcion_principal_con_telefonos(opcion_principal, central):
    match opcion_principal: #Utilizamos match-case para las tres opciones del menú principal
        case "1":
            telefono = opcion_crear_nuevo_tel() #se asigna el teléfono instanciado a la variable teléfono para luego pasar la información al CSV
            escribir_csv_unico(telefono)
            registroUnDispositivoCentral(telefono, central)
        case "2":
            opcion_operar(central)
        case "3":
            finalizar_programa(central)
            return False
    return True

def manejar_opcion_principal_sin_telefonos(opcion_principal, central):
    match opcion_principal:
        case "1":
            telefono = opcion_crear_nuevo_tel()
            escribir_csv_unico(telefono)
            registroUnDispositivoCentral(telefono, central)
        case "2":
            finalizar_programa(central)
            return False
    return True

def finalizar_programa(central):
    Telefono.apagar_todos()
    desactivarDispositivosCentral(central)
    escribir_csv_todos()
    print("\nPrograma finalizado\n")

##############################################
#FUNCIÓN MAIN
##############################################

def main(): #Función que ejecuta el menú principal dentro de un ciclo while y que sale si el usuario selecciona la opción de "Salir"
    try:
        central = inicializar_central()
        sigue = True
        while sigue:
            opcion_principal = menu_principal()

            if Telefono.telefonos:
                sigue = manejar_opcion_principal_con_telefonos(opcion_principal, central)
            else:
                sigue = manejar_opcion_principal_sin_telefonos(opcion_principal, central)
                
    except (ValueError, KeyError) as e:
        print(f"Error: {e}")
    except Exception as e:
        print(e)