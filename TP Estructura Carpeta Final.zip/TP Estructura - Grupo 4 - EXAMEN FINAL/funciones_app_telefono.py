#import
from Class_Menu import *
from Class_Telefono import *
from funciones_pedido_inputs import *

#Menú principal - opción 1 - menú Abrir app - app Teléfono

def menuAppTelefono(telefono_operando):
    texto_apptel = "\nElija la opción que desee: "
    if telefono_operando.apps["Telefono"].verificar_hay_llamada():
        opciones_apptel = {"1":"Llamar a otro teléfono","2":"Terminar llamada en curso","3":"Ver historial de llamadas","4":"Volver al menu principal"}
    else:
        opciones_apptel = {"1":"Llamar a otro teléfono","2":"Ver historial de llamadas","3":"Volver al menu principal"}
    menu_apptel = Menu(opciones_apptel,texto_apptel)
    opcion_apptel=menu_apptel.pedir_opcion()
    return opcion_apptel

#Menú principal - opción 1 - menú Abrir app - app Teléfono - opción 1

def opcion1_menu_apptel(telefono_operando, central):
    print("\nEsta es su agenda de contactos: ")
    
    if len(telefono_operando.apps["Contactos"].contactos)==0:
        print("Su agenda de teléfonos se encuentra vacía. Ingrese el teléfono al que desea llamar.")
        pedirNumYLlamar(telefono_operando, central)
    else:
        gestionar_llamada_desde_agenda(telefono_operando, central)

def gestionar_llamada_desde_agenda(telefono_operando, central):
    texto_llamar = "\nElija el contacto al que desea llamar: "
    opciones_contactos = telefono_operando.apps["Contactos"].contactos.copy()
    opciones_contactos.append("Quiero llamar a otro destinatario que no está en mi agenda")
    menu_llamar = Menu(opciones_contactos, texto_llamar)
    opcion_contacto = menu_llamar.pedir_opcion()

    if opciones_contactos[int(opcion_contacto) - 1] != "Quiero llamar a otro destinatario que no está en mi agenda":
        gestionar_llamada_a_contacto(telefono_operando, central, int(opcion_contacto) - 1)
    else:
        pedirNumYLlamar(telefono_operando, central)

def gestionar_llamada_a_contacto(telefono_operando, central, indice_contacto):
    contacto = telefono_operando.apps["Contactos"].contactos[indice_contacto]

    if len(contacto["numeros"]) == 1:
        realizar_llamada(telefono_operando, central, contacto["nombre"], contacto["numeros"][0])
    else:
        texto_elegir_numero = "\nElija qué número de su contacto desea llamar: "
        menu_numeros = Menu(contacto["numeros"], texto_elegir_numero)
        opcion_numero = menu_numeros.pedir_opcion()
        numero_seleccionado = contacto["numeros"][int(opcion_numero) - 1]
        realizar_llamada(telefono_operando, central, contacto["nombre"], numero_seleccionado)

def realizar_llamada(telefono_operando, central, nombre_contacto, numero):
    if telefono_operando.apps["Telefono"].verificar_hay_llamada():
        print("Error: ya hay una llamada en curso, debe cortarse para realizar otra llamada.")
        return

    tel = buscar_telefono_por_numero(numero)

    if not tel:
        print("Error: está intentando contactar a un dispositivo no registrado.")
        return

    if tel.apps["Telefono"].verificar_hay_llamada():
        print("Error: ya hay una llamada en curso en el dispositivo de destino.")
    else:
        llamada, estado = central.solicitar_comunicacion(str(telefono_operando.id), str(tel.id), "llamada")
        if "Error" in llamada:
            print(llamada)
        else:
            manejar_resultado_llamada(telefono_operando, nombre_contacto, numero, estado)

def buscar_telefono_por_numero(numero):
    for telefono in Telefono.telefonos.values():
        if telefono.num_telefono == numero:
            return telefono
    return None

def manejar_resultado_llamada(telefono_operando, nombre_contacto, numero, estado):
    telefono_operando.apps["Telefono"].llamar(nombre_contacto, numero)
    if estado == "no establecida":
        print("El teléfono al que está intentando llamar no se encuentra disponible para recibir su llamada.")
        telefono_operando.apps["Telefono"].terminar_llamada()
    else:
        recibirLlamada(numero, telefono_operando)

#Menú principal - opción 1 - menú Abrir app - app Teléfono - opción 2

def opcion2_menu_apptel(telefono_operando):
    telefono_operando.apps["Telefono"].terminar_llamada()
    if len(telefono_operando.apps["Telefono"].historial_llamadas)>0:
        num_al_que_llamo=telefono_operando.apps["Telefono"].historial_llamadas[-1][1]
        for telefono in Telefono.telefonos.values():
            if telefono.num_telefono==num_al_que_llamo:
                if len(telefono.apps["Telefono"].historial_llamadas)>0:
                    if telefono_operando.apps["Telefono"].historial_llamadas[-1][1]==telefono.num_telefono and telefono.apps["Telefono"].historial_llamadas[-1][1]==telefono_operando.num_telefono:
                        
                        telefono.apps["Telefono"].terminar_llamada()
                    else:
                        print("No hay llamada para finalizar")

#Menú principal - opción 1 - menú Abrir app - app Teléfono - opción 3

def opcion3_menu_apptel(telefono_operando):
    telefono_operando.apps["Telefono"].ver_historial_llamadas()

#Menú principal - opción 2 - recibir llamada

def recibirLlamada(numero,telefono_operando):
    for telefono in Telefono.telefonos.values():
            if telefono.num_telefono==numero:
                print(f"\nAnuncio de telefono con ID {telefono.id} ------>")
                nombre=None
                for contacto in telefono.apps["Contactos"].contactos:
                    if telefono_operando.num_telefono in contacto['numeros']:
                        nombre=contacto["nombre"]
                if nombre!=None:
                    telefono.apps["Telefono"].recibir_llamada(nombre)
                    telefono.apps["Telefono"].agregarAlHistorial(nombre,telefono_operando.num_telefono)
                else:
                    telefono.apps["Telefono"].recibir_llamada(telefono_operando.num_telefono)
                    telefono.apps["Telefono"].agregarAlHistorial("Sin nombre",telefono_operando.num_telefono)
                    
#Menú principal - opción 2 - pedir número y llamar

def gestionar_comunicacion_llamada(central, telefono_operando, tel, numero, nombre_contacto):
    llamada, estado = central.solicitar_comunicacion(str(telefono_operando.id), str(tel.id), "llamada")
    if "Error" in llamada:
        print(llamada)
    else:
        print(llamada)
        telefono_operando.apps["Telefono"].llamar(nombre_contacto, numero)

        if estado == "no establecida":
            print("El teléfono al que está intentando llamar no se encuentra disponible para recibir su llamada")
            telefono_operando.apps["Telefono"].terminar_llamada()
        else:
            recibirLlamada(numero, telefono_operando)

def pedirNumYLlamar(telefono_operando, central):

    if telefono_operando.apps["Telefono"].verificar_hay_llamada():
        print("Error: ya hay una llamada en curso, debe cortar para realizar otra llamada")
        return
    numero = pedirNumeroContacto()
    tel = buscar_telefono_por_numero(numero)
    if not tel:
        print("Error: está intentando contactar a un dispositivo no registrado.")
        return
    if tel.apps["Telefono"].verificar_hay_llamada():
        print("Error: ya hay una llamada en curso, debe cortar para realizar otra llamada")  
        return

    gestionar_comunicacion_llamada(central, telefono_operando, tel, numero, nombre_contacto="Sin nombre")

#Menú principal - opción 1 - menú Abrir app - App teléfono - main

def opcion_abrir_app_telefono(telefono_operando,central):
    sigue=True
    while sigue:
        opcion_apptel=menuAppTelefono(telefono_operando)
        if telefono_operando.apps["Telefono"].verificar_hay_llamada():
            match opcion_apptel:
                case '1':
                    opcion1_menu_apptel(telefono_operando,central)
                case "2":
                    opcion2_menu_apptel(telefono_operando)
                case "3":
                    opcion3_menu_apptel(telefono_operando)
                case "4":
                    sigue=False
        else:
            match opcion_apptel:
                case '1':
                    opcion1_menu_apptel(telefono_operando,central)
                case "2":
                    opcion3_menu_apptel(telefono_operando)
                case "3":
                    sigue=False