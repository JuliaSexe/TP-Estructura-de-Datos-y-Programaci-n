#import
from Class_Menu import *
from funciones_validaciones import *

##############################################
#FUNCIONES DE PEDIDO DE INPUTS
##############################################

#Menú principal - opción 1 - pedir Nombre

def pedirNombre(opcion_nombre): #Pide el nombre y si el usuario quiere cambiar el default 'Mi teléfono', significa que eligió la opción 1 y luego ingresa el nombre, si no es válido, lo vuelve a pedir
    if opcion_nombre=="1":
        cumple=False
        while not cumple:
            nombre=input("\nIngrese el nuevo nombre para su teléfono: ")
            if not validarNombre(nombre):
                print('\nError: el nombre del teléfono debe contener al menos un caracter')
            else:
                cumple=True
    else:
        nombre="Mi teléfono"
    return nombre

#Menú principal - opción 1 - pedir Número de teléfono

def pedirNumero(): ##Pide el número de teléfono y lo valida. Si no es válido se le informa al usuario y se le vuelve a pedir. Devuelve el número de teléfono
    cumple = False
    while not cumple:
        numero = input('\nIngrese el número de teléfono (10 dígitos numéricos): ')
        if not validarNumeroTelefono(numero):
            print('\nError: el número de teléfono debe contener 10 dígitos numéricos')
        elif not validarRepeticionTelefono(numero):
            print("\nError: el número de teléfono ya existe")
        else:
            cumple=True
            
    return numero

#Menú principal - opción 1 - pedir Código de desbloqueo

def pedirCodigo(): ##Pide el código y lo valida. Va a pedirlo mientras no sea válido, y si se ingresa un código inválido se le informa al usuario. Devuelve el código
    cumple = False
    while not cumple:
        codigo = input('\nIngrese el código de desbloqueo (4 digitos): ')
        if validarCodigo(codigo):
            cumple = True
        else:
            print('\nError: el código de desbloqueo debe ser de 4 dígitos numéricos')
    return codigo

#Menú principal - opción 2 - menú Abrir app - app Contactos - opción 1 - pedir Nombre Contacto

def pedirNombreContacto():
    cumple_nombre=False
    while not cumple_nombre:
        nombre = input("Ingrese el nombre del nuevo contacto: ")
        if validarNombre(nombre):
            cumple_nombre=True
        else:
            print('\nError: el nombre del contacto debe contener al menos un caracter')
    return nombre

#Menú principal - opción 2 - menú Abrir app - app Contactos - opción 1 - pedir Número Contacto

def pedirNumeroContacto():
    cumple_numero=False
    while not cumple_numero:
        numero= input("Ingrese el número de teléfono: ")
        if validarNumeroTelefono(numero):
            cumple_numero=True
        else:
            print('\nError: el número de teléfono debe contener 10 dígitos numéricos')
    return numero

#Menú principal - opción 2 - menú Abrir app - app Email - opción 1 - pedir email

def pedirEmailPersonal():
    cumple=False
    while not cumple:
        email=input("Ingrese su dirección de email que desea registrar. ATENCIÓN: este será su mail permanente para la App e-mail: ")
        if validarEmail(email):
            cumple=True
        else:
            print('\nError: el email ingresado no cumple con el formato correcto')
    return email

#Menú principal - opción 2 - menú Abrir app - app Email - opción 2 - pedir email

def pedirEmailParaEnviar():
    cumple=False
    while not cumple:
        email=input("Ingrese la dirección de email a la que desea enviar su correo: ")
        if validarEmail(email):
            cumple=True
        else:
            print('\nError: el email ingresado no cumple con el formato correcto')
    return email

#Menú principal - opción 2 - menú Abrir app - app Email - opción 2 - pedir asunto

def pedirAsunto():
    cumple=False
    while not cumple:
        asunto=input("Ingrese el asunto del email que desea enviar: ")
        if validarAsunto(asunto)==True:
            cumple=True
        elif validarAsunto(asunto)=="(sin asunto)":
            asunto="(sin asunto)"
            cumple=True
        else:
            print('\nError: el asunto ingresado no cumple con el formato correcto')
    return asunto

def pedirContenido():
    cumple=False
    while not cumple:
        contenido=input("Ingrese el contenido de su correo/mensaje: ")
        if validarContenido(contenido):
            cumple=True
        else:
            print('\nError: el contenido ingresado no cumple con el formato correcto')
    return contenido

#Menú principal - opción 2 - menú Abrir app - app Mensajería - opción 4 - pedir tipo de mensaje a eliminar

def pedirTipoMensaje():
    texto_tipo = "\nElija el tipo de mensaje que desea eliminar: "
    opciones_tipo = {"1":"Mensaje enviado","2":"Mensaje recibido"}
    menu_tipo = Menu(opciones_tipo,texto_tipo)
    opcion_tipo=menu_tipo.pedir_opcion()
    if opcion_tipo=="1":
        tipo="E"
    else:
        tipo="R"
    return tipo

def pedirMensajeEliminar(telefono_operando, tipo):
    texto_mensaje = "\nElija el mensaje que desea eliminar: "
    opciones_mensajes = obtener_opciones_mensajes(telefono_operando, tipo)

    if len(opciones_mensajes)==0:
        print("Su bandeja está vacía")
        return None

    mensaje_a_eliminar_indice = seleccionar_mensaje_a_eliminar(opciones_mensajes, texto_mensaje)
    return mensaje_a_eliminar_indice

def obtener_opciones_mensajes(telefono_operando, tipo):
    if tipo == "E":
        return telefono_operando.apps["Mensajes"].mensajes_enviados.get(str(telefono_operando.id), [])
    else:
        return telefono_operando.apps["Mensajes"].mensajes_recibidos.get(str(telefono_operando.id), [])

def seleccionar_mensaje_a_eliminar(opciones_mensajes, texto_mensaje):
    menu_mensaje = Menu(opciones_mensajes, texto_mensaje)
    opcion_mensaje = menu_mensaje.pedir_opcion()

    if len(opciones_mensajes) == 1:
        return 0
    else:
        return int(opcion_mensaje) - 1