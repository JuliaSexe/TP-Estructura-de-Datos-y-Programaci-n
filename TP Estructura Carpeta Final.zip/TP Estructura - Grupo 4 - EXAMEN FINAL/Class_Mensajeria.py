from Class_Aplicacion import *
from datetime import datetime
from Class_Exportador import Exportador, ExportadorMensaje

class Mensajes(Aplicacion): 
    
    def __init__(self,mensajes_enviados=None,mensajes_recibidos=None):
        super().__init__('Mensajes')
        self.mensajes_enviados = mensajes_enviados if mensajes_enviados is not None else {} ##Clave: id del tel que envia. Valor: lista de mensajes enviados con primer elemento emisor
        self.mensajes_recibidos = mensajes_recibidos if mensajes_recibidos is not None else{} ##igual q arriba pero al reves 
        self.exportador = ExportadorMensaje('mensajes.csv')
        self.mensajes_cargados = self.exportador.leer() or []
        
        for mensaje in self.mensajes_cargados: 
            emisor = mensaje['emisor']
            self.mensajes_enviados.setdefault(emisor, []).append(mensaje)
            if mensaje['estado'] == 'entregado':
                receptor = mensaje['receptor']
                self.mensajes_recibidos.setdefault(receptor, []).append(mensaje)
        
        self.mensajes_recibidos = {str(k): v for k, v in self.mensajes_recibidos.items()}
        self.mensajes_enviados = {str(k): v for k, v in self.mensajes_enviados.items()}
    
    def crear_mensaje(self, id_emisor, id_receptor, contenido, estado = 'pendiente', id_comunicacion = None): 
        return {'emisor': id_emisor,'receptor': id_receptor,'contenido': contenido,'hora': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),'estado': estado,'id_comunicacion': id_comunicacion}
    
    def enviar_mensajes(self, id_emisor, id_receptor, contenido, central = None, estado='pendiente'): ##envia mensajes
        if central: 
            comunicacion,estado = central.solicitar_comunicacion(id_emisor, id_receptor, 'mensaje')
            if isinstance(comunicacion, str) and 'Error' in comunicacion: 
                print(comunicacion)
                return
            estado = comunicacion['estado']
            id_comunicacion = comunicacion['id_comunicacion']
        else:
            id_comunicacion = None
        mensaje = self.crear_mensaje(id_emisor, id_receptor, contenido, estado, id_comunicacion)
        self.mensajes_enviados.setdefault(id_emisor, []).append(mensaje)
        self.mensajes_cargados.append(mensaje)
        self.exportador.exportar([mensaje])
        print(f"\nMensaje {'pendiente' if estado == 'pendiente' else 'enviado'} a: {id_receptor}")
        
    def recibir_mensajes_pendientes(self, id_receptor, central = None): ##recibe los mnsj pendientes
        self.mensajes_cargados = self.exportador.leer() or []
        mensajes_recibidos = False 
        for mensaje in self.mensajes_cargados: 
            if (mensaje['receptor'] == id_receptor) and (mensaje['estado'] == 'pendiente'): 
                mensaje['estado'] = 'entregado'
                mensajes_recibidos = True
                self.mensajes_recibidos.setdefault(id_receptor, []).append(mensaje)
                print(f"\nMensaje recibido de: {mensaje['emisor']}, contenido: {mensaje['contenido']}")
                
                # Si hay central, confirmar entrega
                if central and mensaje.get('id_comunicacion'):
                    central.confirmar_entrega_mensaje(mensaje['id_comunicacion'])
        if mensajes_recibidos: 
            self.exportador.exportar_mensajes(self.mensajes_cargados)
    
    def ver_bandeja_entrada(self, id_receptor): ##Mmuestra mensajes q se recibieron
        mensajes = self.mensajes_recibidos.get(str(id_receptor), []) ##El segundo argumento ([]) es el valor predeterminado que se devolverá si la clave no existe en el diccionario.
        if not mensajes: 
            print('\nNo hay mensajes en la bandeja de entrada') 
        else:
            print(f'\nBandeja de entrada de: {id_receptor}')
            for mensaje in mensajes: 
                print(f'\n[{mensaje["hora"]}] DE {mensaje["emisor"]}: {mensaje["contenido"]}')

    def ver_historial_enviados(self, id_emisor): ##muestra mensjaes q se enviaron
        mensajes = self.mensajes_enviados.get(str(id_emisor), [])
        if not mensajes:
            print("\nNo hay mensajes en el historial de enviados.")
        else:
            print(f"\nHistorial de mensajes enviados por {id_emisor}:")
            for mensaje in mensajes:
                print(f"[{mensaje['hora']}] A {mensaje['receptor']}: {mensaje['contenido']}")

    def eliminar_mensaje(self, tipo, telefono_id, indice): ##elimina mensaje
        if tipo == "E": ##pq si tipo es enviado entra
            lista = self.mensajes_enviados.get(telefono_id, [])
        else:
            lista = self.mensajes_recibidos.get(telefono_id, [])
        
        if not lista or indice < 0 or indice >= len(lista):
            print("\nMensaje no encontrado.")
            return 
        mensaje_eliminado = lista.pop(indice)
        self.mensajes_cargados = [mensaje for mensaje in self.mensajes_cargados if not (mensaje['emisor'] == mensaje_eliminado['emisor'] and mensaje['receptor'] == mensaje_eliminado['receptor'] and mensaje['hora'] == mensaje_eliminado['hora'])]
        self.exportador.exportar_mensajes(self.mensajes_cargados)
        print('\nMensaje eliminado correctamente')
        
                
    def recibir_mensaje(self, id_emisor, id_receptor, contenido):
        mensaje = self._crear_mensaje(id_emisor, id_receptor, contenido, estado='entregado')
        self.mensajes_recibidos.setdefault(id_receptor, []).append(mensaje)
        self.exportador.exportar([mensaje])
        print(f'\nMensaje recibido de: {id_emisor}')