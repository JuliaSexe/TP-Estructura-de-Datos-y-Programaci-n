class Menu:
    def __init__(self, opciones, titulo_menu:str): ##Acepta que sed le pase una lista o un dict del estilo ['primera op', 'segunda op', ...] y ahi se asigna 1. primera op 2. segudna op etc
        if not isinstance(opciones, (list, dict)): ##Validamos que las opciones sean una lista o un diccionario
            raise ValueError('Error: Las opciones deben ser una lista o diccionario')
        if isinstance(opciones, list): ##Si es una litsa, la paso a un diccionario con clave numeros ordenados: valor el elemento de la lista
            self.opciones = {str(i + 1): opciones[i] for i in range(len(opciones))}
        else: 
            self.opciones = opciones
        if not isinstance(titulo_menu, str): ##Validamos que el texto sea un str
            raise ValueError('Error: el texto del menú debe ser un dato de tipo string')
        self.titulo_menu = titulo_menu
    
    def __str__(self): 
        menu = self.titulo_menu
        for key, value in self.opciones.items(): 
            menu += f'\n{key}. {value}'
        return menu ##Método mágico que devuelve el menú ordenado
    
    def pedir_opcion(self): ##muestra el menu y Pide una opción 
        print(self)
        opcion = input('\nIngrese una opción: ')
        return self.validar_menu(opcion) ##Valida la opción
    
    def validar_menu(self, opcion:str): ##Valida que la opción elegida esté en el rango, caso contrario pide que se ingrese nuevamente
        while opcion not in self.opciones:
            opcion = input('\nError: ingrese una opción correcta: ')
        return opcion
    
    def obtener_opcion(self, opcion):
        return self.opciones.get(opcion)