class Aplicacion: 
    apps_basicas = {'Telefono': None, 'Contactos': None, 'Mensajes': None, 'Email': None, 'AppStore': None,'Configuracion': None}  ##Usamos un dicc porque queremos guardar el objeto aplicacion asociado a cada una de las apps. No usamos una tupla porque, auqneu para analizar los nombres que no van acambiar seria mas eficiente, necesitamos tener una manera de guardar el objeto asociado a cada clave unica que serian los nombres de las apps basicas. 
    
    def __init__(self,nombre):
            self.ejecucion = False ##Se inicializa en False porque no se esta ejecutando la app 
            if nombre not in Aplicacion.apps_basicas: 
                raise ValueError('La aplicacion no se encuentra dentro de las aplicaciones basicas')
            self.nombre = nombre
            Aplicacion.apps_basicas[nombre] = self
        
    def abrir_app(self): 
       if not self.ejecucion:
           self.ejecucion = True 
           print(f'La aplicacion {self.nombre} se encuentra en ejecución.')
           return True
       print(f'La App {self.nombre} ya se encuentra en ejecución.')
       return False 
           
    def cerrar_app(self): 
        if self.ejecucion: 
            self.ejecucion = False 
            print(f'La aplicación {self.nombre} ha sido cerrada')
            return True 
        print(f'Error: La App {self.nombre} no se encuentra abierta.')
        return False
            
    def eliminar_app(self, nombre: str):
        if nombre in Aplicacion.apps_basicas.keys(): 
            print('Error: la aplicación que desea eliminar forma parte de las básicas. No puede ser eliminada')
    
    def __str__(self):
        if self.ejecucion: 
            estado = 'abierta'
        else: 
            estado = 'cerrada'
        return f'\nEl estado de ejecución de la aplicación {self.nombre} es: {estado}'