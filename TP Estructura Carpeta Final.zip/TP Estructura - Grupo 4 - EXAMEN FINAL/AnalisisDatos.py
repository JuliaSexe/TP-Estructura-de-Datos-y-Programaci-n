import matplotlib.pyplot as plt
import random
import csv
from collections import defaultdict

file = "PlayStoreData.csv"

##listas para almacenar los datos
data = []
categorias = []
content_ratings = []
types = []
prices = []

##leemos los datos del csv
with open(file, 'r', encoding='utf-8') as archivo:
    reader = csv.DictReader(archivo)
    for fila in reader:
        data.append(fila)
        categorias.append(fila['Category'])
        content_ratings.append(fila['Content Rating'])
        types.append(fila['Type'])
        prices.append(fila['Price'])


##Gráfico 1: Número de aplicaciones por categoría. muestra la distribución de aplicaciones por categoría, y las categorías se ordenan de mayor a menor según el número de aplicaciones.
conteo_categorias = {} ##diccionario donde la clave es la categoría y el valor es el número de aplicaciones en esa categoría

for app in data:
    categoria = app['Category']
    if categoria in conteo_categorias:
        conteo_categorias[categoria] += 1
    else:
        conteo_categorias[categoria] = 1

categorias_ordenadas = list(conteo_categorias.keys()) ##paso la info a listas
cuentas_ordenadas = list(conteo_categorias.values())
categorias_ordenadas, cuentas_ordenadas = zip(*sorted(zip(categorias_ordenadas, cuentas_ordenadas), key=lambda x: x[1], reverse=True)) ##el primer zip me lo convierte en pares de tuplas, el sorted ordena en funcion del segundo elemento de la tupla osea el numero, y el ultimo zip lo deszipea

plt.figure(figsize=(16, 10))
colores = [(random.random(), random.random(), random.random()) for _ in range(len(categorias_ordenadas))] ##random.random() genera un número aleatorio entre 0 y 1 para cada componente RGB
plt.bar(categorias_ordenadas, cuentas_ordenadas, color=colores) ##genera grafico aleatorio con colores distintos
plt.title('Número de Aplicaciones por Categoría', fontsize=18, weight='bold')
plt.xlabel('Categoría', fontsize=14)
plt.ylabel('Número de Apps', fontsize=14)
plt.xticks(rotation=90, fontsize=12)
plt.grid(True, axis='y', linestyle='--', alpha=0.6)
plt.tight_layout()
plt.show()

##Gráfico 2: Cantidad de aplicaciones gratuitas por categoría. muestra la distribución de aplicaciones gratuitas por categoría, y las categorías se ordenan de mayor a menor según el número de aplicaciones gratuitas.
categorias_gratis = [categoria for categoria, tipo in zip(categorias, types) if tipo == 'Free'] ##crea una lista solo de apps gratis

conteo_gratis = defaultdict(int) ##defaultdict(int) --> crea un diccionario con un valor inicial de 0 para cada clave nueva.
for categoria in categorias_gratis:
    conteo_gratis[categoria] += 1

categorias_gratis_ordenadas, apps_gratis_ordenadas = zip(*sorted(conteo_gratis.items(), key=lambda x: x[1], reverse=True))

plt.figure(figsize=(16, 10))
colores = [(random.random(), random.random(), random.random()) for _ in range(len(categorias_gratis_ordenadas))]
plt.bar(categorias_gratis_ordenadas, apps_gratis_ordenadas, color=colores)
plt.title('Número de Aplicaciones Gratuitas por Categoría', fontsize=18, weight='bold')
plt.xlabel('Categoría', fontsize=14)
plt.ylabel('Número de Apps Gratuitas', fontsize=14)
plt.xticks(rotation=90, fontsize=12)
plt.grid(True, axis='y', linestyle='--', alpha=0.6)
plt.tight_layout()
plt.show()

##Gráfico 3: Porcentaje de aplicaciones gratuitas por categoría. muestra el porcentaje de aplicaciones gratuitas por categoría.las categorías se ordenan de mayor a menor según el porcentaje de aplicaciones gratuitas.
porcentaje_gratis = {}

for categoria in conteo_categorias.keys(): ## recorre todas las categorías, calcula cuántas de esas aplicaciones son gratuitas y calcula el porcentaje 
    total_apps = conteo_categorias[categoria]
    gratis = conteo_gratis[categoria] if categoria in conteo_gratis else 0 
    porcentaje_gratis[categoria] = (gratis / total_apps) * 100

categorias_ordenadas, porcentaje_ordenado = zip(*sorted(porcentaje_gratis.items(), key=lambda x: x[1], reverse=True))

plt.figure(figsize=(16, 10))
colores = [(random.random(), random.random(), random.random()) for _ in range(len(categorias_ordenadas))]
plt.bar(categorias_ordenadas, porcentaje_ordenado, color=colores)
plt.title('Porcentaje de Aplicaciones Gratuitas por Categoría', fontsize=18, weight='bold')
plt.xlabel('Categoría', fontsize=14)
plt.ylabel('Porcentaje de Apps Gratuitas (%)', fontsize=14)
plt.xticks(rotation=90, fontsize=12)
plt.grid(True, axis='y', linestyle='--', alpha=0.6)
plt.tight_layout()
plt.show()

##Gráfico 4: Número de aplicaciones pagas por categoría muestra la distribución de aplicaciones pagas por categoría. y las categorías se ordenan de mayor a menor según el número de aplicaciones pagas.
categorias_pagas = [categoria for categoria, tipo in zip(categorias, types) if tipo != 'Free'] ## lista de categorías que contienen aplicaciones pagas

conteo_pagas = defaultdict(int)
for categoria in categorias_pagas:
    conteo_pagas[categoria] += 1

categorias_pagas_ordenadas, apps_pagas_ordenadas = zip(*sorted(conteo_pagas.items(), key=lambda x: x[1], reverse=True))

plt.figure(figsize=(16, 10))
colores = [(random.random(), random.random(), random.random()) for _ in range(len(categorias_pagas_ordenadas))]
plt.bar(categorias_pagas_ordenadas, apps_pagas_ordenadas, color=colores)
plt.title('Número de Aplicaciones Pagas por Categoría', fontsize=18, weight='bold')
plt.xlabel('Categoría', fontsize=14)
plt.ylabel('Número de Apps Pagas', fontsize=14)
plt.xticks(rotation=90, fontsize=12)
plt.grid(True, axis='y', linestyle='--', alpha=0.6)
plt.tight_layout()
plt.show()

##Gráfico 5: Porcentaje de aplicaciones pagas por categoría muestra el porcentaje de aplicaciones pagas por categoría. las cat se ordenan de mayor a menor según el porcentaje de aplicaciones pagas.
porcentaje_pagas = {}

for categoria in conteo_categorias.keys():
    total_apps = conteo_categorias[categoria]
    pagas = conteo_pagas[categoria] if categoria in conteo_pagas else 0 ##misma logica q arriba
    porcentaje_pagas[categoria] = (pagas / total_apps) * 100

categorias_ordenadas, porcentaje_ordenado = zip(*sorted(porcentaje_pagas.items(), key=lambda x: x[1], reverse=True))

plt.figure(figsize=(16, 10))
colores = [(random.random(), random.random(), random.random()) for _ in range(len(categorias_ordenadas))]
plt.bar(categorias_ordenadas, porcentaje_ordenado, color=colores)
plt.title('Porcentaje de Aplicaciones Pagas por Categoría', fontsize=18, weight='bold')
plt.xlabel('Categoría', fontsize=14)
plt.ylabel('Porcentaje de Apps Pagas (%)', fontsize=14)
plt.xticks(rotation=90, fontsize=12)
plt.grid(True, axis='y', linestyle='--', alpha=0.6)
plt.tight_layout()
plt.show()

##Gráfico 6: Precio promedio por categoría muestra el precio promedio de las aplicaciones por categoría.
precios_por_categoria = defaultdict(list) ##defaultdict de listas para almacenar los precios de las aplicaciones agrupados por categoría.

for categoria, precio in zip(categorias, prices):
    if precio != '0' and precio != '0.0' and precio != 'Free':
        try:
            precios_por_categoria[categoria].append(float(precio.replace('$', '').replace(',', '')))
        except ValueError:
            continue  ##ignoramos precios invalidos

precios_promedio = {categoria: sum(precios) / len(precios) for categoria, precios in precios_por_categoria.items()} ##el precio promedio para cada categoría se saca dividiendo la suma de los precios por la cantidad de precios en la lista

categorias_ordenadas, precios_promedio_ordenados = zip(*sorted(precios_promedio.items(), key=lambda x: x[1], reverse=True))

plt.figure(figsize=(16, 10))
plt.bar(categorias_ordenadas, precios_promedio_ordenados, color='gold')
plt.title('Precio Promedio por Categoría', fontsize=18, weight='bold')
plt.xlabel('Categoría', fontsize=14)
plt.ylabel('Precio Promedio ($)', fontsize=14)
plt.xticks(rotation=90, fontsize=12)
plt.grid(True, axis='y', linestyle='--', alpha=0.6)
plt.tight_layout()
plt.show()


##Gráfico 7: Relación entre número de aplicaciones gratuitas y categorías. muestra la relación entre el número de aplicaciones gratuitas y las categorías.
##una alternativa del grafico de barras como grafico lineal
categorias_gratis = [categoria for categoria, tipo in zip(categorias, types) if tipo == 'Free']

conteo_gratis_lineal = defaultdict(int)

for categoria in categorias_gratis:
    conteo_gratis_lineal[categoria] += 1

categorias_gratis_ordenadas, apps_gratis_ordenadas = zip(*sorted(conteo_gratis_lineal.items(), key=lambda x: x[1], reverse=True))

plt.figure(figsize=(16, 8))
plt.plot(categorias_gratis_ordenadas, apps_gratis_ordenadas, marker='o', color='dodgerblue', linestyle='-', linewidth=2, markersize=8)
plt.title('Relación entre número de aplicaciones gratuitas y categorías', fontsize=18, weight='bold')
plt.xlabel('Categoría', fontsize=14)
plt.ylabel('Número de Apps Gratuitas', fontsize=14)
plt.xticks(rotation=90, fontsize=12)
plt.grid(True, axis='y', linestyle='--', alpha=0.6)
plt.tight_layout()
plt.show()

##Gráfico 8: Distribución de Aplicaciones por Clasificación de Contenido muestra la distribución de las aplicaciones por clasificación de contenido.
conteo_content_rating = defaultdict(int) 

for content_rating in content_ratings:
    conteo_content_rating[content_rating] += 1

labels = list(conteo_content_rating.keys())
sizes = list(conteo_content_rating.values())

plt.figure(figsize=(12, 12))
patches, texts, autotexts = plt.pie(sizes, labels=labels, autopct='%1.1f%%', colors=plt.cm.Paired.colors, startangle=140)
##autopct='%1.1f%%' muestra el porcentaje de cada segmento con un formato de un decimal.
##colors=plt.cm.Paired.colors asigna una paleta de colores predefinida (Paired) para dar variedad de colores
##startangle=140 rota el gráfico 

for autotext in autotexts:
    autotext.set_size(8)
    autotext.set_color('white')

plt.axis('equal')
plt.title('Distribución de Aplicaciones por Clasificación de Contenido', fontsize=18, weight='bold')
plt.legend(patches, labels, loc='upper left', fontsize=10)
plt.tight_layout()
plt.show()