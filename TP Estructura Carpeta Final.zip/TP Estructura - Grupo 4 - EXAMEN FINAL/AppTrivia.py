def juego_trivia_python():

    preguntas = {
        "¿Quién es el ayudante que mejor resuelve las crisis del grupo 4?": 'c',
        "¿Qué palabra clave se usa para definir una función en Python?": "a",
        "¿Cuál es el resultado de 3 ** 2 en Python?": "b",
        "¿Qué estructura se usa para almacenar pares de clave-valor en Python?": "c",
        "¿Qué tipo de bucle se usa cuando sabes la cantidad exacta de repeticiones?": "a",
        "¿Cuál es el operador de comparación para 'igual' en Python?": "c",
        "¿Qué palabra clave se usa para crear una clase en Python?": "b",
        "¿Qué función se usa para obtener la longitud de una lista en Python?": "c",
        "¿Cuál es el tipo de dato de True y False en Python?": "a",
        "¿Cuál es el índice inicial de una lista en Python?": "b",
        "¿Qué palabra clave se usa para crear una instancia de una clase en Python?": "c",
        "¿Qué concepto en POO se refiere a restringir el acceso directo a algunos datos de un objeto?": "b",
        "¿Cómo se accede a un método de un objeto en Python?": "a"
    }

    opciones = {
        "¿Quién es el ayudante que mejor resuelve las crisis del grupo 4?": ["a) capaz guido", "b) me parece que guido", "c) GUIDOOOO!!!!!!!!!"],
        "¿Qué palabra clave se usa para definir una función en Python?": ["a) def", "b) func", "c) function"],
        "¿Cuál es el resultado de 3 ** 2 en Python?": ["a) 5", "b) 9", "c) 6"],
        "¿Qué estructura se usa para almacenar pares de clave-valor en Python?": ["a) Lista", "b) Tupla", "c) Diccionario"],
        "¿Qué tipo de bucle se usa cuando sabes la cantidad exacta de repeticiones?": ["a) for", "b) while", "c) if"],
        "¿Cuál es el operador de comparación para 'igual' en Python?": ["a) =", "b) >", "c) =="],
        "¿Qué palabra clave se usa para crear una clase en Python?": ["a) object", "b) class", "c) def"],
        "¿Qué función se usa para obtener la longitud de una lista en Python?": ["a) size()", "b) length()", "c) len()"],
        "¿Cuál es el tipo de dato de True y False en Python?": ["a) Booleano", "b) Entero", "c) Cadena"],
        "¿Cuál es el índice inicial de una lista en Python?": ["a) 1", "b) 0", "c) -1"],
        "¿Qué palabra clave se usa para crear una instancia de una clase en Python?": ["a) create", "b) init", "c) new"],
        "¿Qué concepto en POO se refiere a restringir el acceso directo a algunos datos de un objeto?": ["a) Herencia", "b) Encapsulación", "c) Polimorfismo"],
        "¿Cómo se accede a un método de un objeto en Python?": ["a) objeto.metodo()", "b) metodo.objeto()", "c) metodo->objeto"]
    }

    puntaje = 0

    print("Juego de Trivia!")
    print("Responde las siguientes preguntas escribiendo la letra de la opción correcta.\n")

    # Recorre las preguntas y verifica las respuestas
    for pregunta, respuesta_correcta in preguntas.items():
        print(pregunta)
        for opcion in opciones[pregunta]:
            print(opcion)

        # Solicita respuesta hasta que el usuario ingrese una opción válida
        respuesta = input("Tu respuesta: ").lower()
        while respuesta not in ['a', 'b', 'c']:
            print("Opción inválida. Por favor ingresa 'a','b' o 'c'")
            respuesta = input("Tu respuesta: ").lower()
        
        if respuesta == respuesta_correcta:
            print("¡Correcto!\n")
            puntaje += 1
        else:
            print("Incorrecto. La respuesta correcta era:", respuesta_correcta, "\n")

    print(f"Tu puntaje final es: {puntaje} de {len(preguntas)}")