import time

def cronometro():
    input("Presiona 'Enter' para iniciar el cronómetro. Presiona 'Ctrl + C' para frenarlo.")
    inicio = time.time()
    
    try:
        while True:
            tiempo_transcurrido = time.time() - inicio
            print(f"\rTiempo: {tiempo_transcurrido:.2f} segundos", end="")
            time.sleep(0.1)
    except KeyboardInterrupt:
        print("\nCronómetro detenido.")
        print(f"Tiempo final: {tiempo_transcurrido:.2f} segundos")