from Class_Aplicacion import *
from Class_AppCalculadora import *

class AppStore(Aplicacion): ##las basicas no se instalan desde appstore
    def __init__(self,apps_instaladas=None):
        super().__init__('AppStore')
        self.apps_instaladas = apps_instaladas if apps_instaladas is not None else {}
        self.apps_disponibles = {'Trivia': 0, 'Ahorcado': 10, 'Cronometro': 15, 'Calculadora': 0} 
    
    def mostrar_apps_disponibles(self):
        print("Aplicaciones disponibles de AppStore:\n")
        for app, precio in self.apps_disponibles.items():
            if precio == 0:
                precio_str = 'Gratuita'
            else:
                precio_str = "$"+str(precio)
            print(f'- {app}: {precio_str}\n')
    
    def mostrar_apps_instaladas(self): ##muestra las apps no basicas instaladas
        if not self.apps_instaladas:
            print("\nNo hay aplicaciones adicionales instaladas")
            return
        
        print("\nAplicaciones instaladas además de las apps básicas:")
        for app in self.apps_instaladas.keys():
            print(f"{app}")
    
    def descargar_app(self, nombre_app):
        
        if nombre_app not in self.apps_disponibles:
            print(f"\nError: La aplicación '{nombre_app}' no existe en AppStore")
            return False
    
        if nombre_app in self.apps_instaladas:
            print(f"\nError: La aplicación '{nombre_app}' ya está instalada")
            return False
        
        if nombre_app in Aplicacion.apps_basicas:
            print(f"\nError: '{nombre_app}' es una aplicación básica y ya está instalada")
            return False
        
        precio = self.apps_disponibles[nombre_app]
        if precio > 0:
            cumple = False
            while not cumple: 
                respuesta = input(f"\nEstá por descargar la aplicación. Su valor es de ${precio} pesos. ¿Desea continuar? (s/n): ")
                if respuesta.lower() == 'n':
                    print("\nDescarga cancelada")
                    return "NO"
                elif respuesta.lower() == 's':
                    cumple = True
                else: 
                    print('\nPor favor ingrese una respuesta correcta')
        if nombre_app == 'Calculadora':
            nueva_app = Calculadora()
        else:
            nueva_app = NuevaAplicacion(nombre_app)
        self.apps_instaladas[nombre_app] = nueva_app
        print(f"\n{nombre_app} se ha instalado correctamente")
        return True
    
    def eliminar_app(self, nombre_app: str): ##elimina app de las instaladas
        if nombre_app in Aplicacion.apps_basicas:
            print(f"\nError: No se puede eliminar '{nombre_app}' porque es una aplicación básica")
            return False
        
        if nombre_app not in self.apps_instaladas:
            print(f"\nError: La aplicación '{nombre_app}' no está instalada")
            return False
        
        # Eliminar la aplicación
        app = self.apps_instaladas[nombre_app]
        if nombre_app=="Calculadora":
            del self.apps_instaladas[nombre_app]
            print(f"\n{nombre_app} ha sido eliminada correctamente")
            return True
        else:
            if app.ejecucion:
                print(f"\nError: No se puede eliminar '{nombre_app}' porque está en ejecución")
                return False
            
            del self.apps_instaladas[nombre_app]
            print(f"\n{nombre_app} ha sido eliminada correctamente")
            return True
    
    def obtener_app_instalada(self, nombre_app: str):
        return self.apps_instaladas.get(nombre_app)

    def obtener_nombres_apps_instaladas(self):
        return tuple(self.apps_instaladas.keys())

class NuevaAplicacion(Aplicacion):
    def __init__(self, nombre: str):
        self.nombre = nombre
        self.ejecucion = False