from datetime import datetime

class Email():
    def __init__(self,remitente:str,destinatario:str,asunto:str,contenido:str,fecha=None,leido=False):
        self.remitente=remitente
        self.destinatario=destinatario
        self.asunto=asunto
        self.contenido=contenido
        self.fecha=fecha if fecha is not None else datetime.now()
        self.leido=leido if leido is not None else False
    
    def marcar_como_leido(self):
        self.leido=True
    
    def ver_contenido(self):
        return f"Contenido: {self.contenido}"
        
    def __str__(self):
        estado = "Leído" if self.leido else "No leído"
        return f"{estado}\nFecha: {self.fecha}\nDe: {self.remitente}\nPara: {self.destinatario}\nAsunto: {self.asunto}\n"