import csv
import matplotlib.pyplot as plt
from collections import defaultdict

def limpiar_installs(valor): ##pasa los valores de tipo '6,000,000+' a numero, le saca el mas y se queda con lo primero q dice
    return int(valor.replace(",", "").replace("+", ""))

file = "PlayStoreData.csv"

installs_por_app = defaultdict(int) ##dict que acumula las descargas por app. busca crear un diccionario en el que las claves sean los nombres de las aplicaciones y los valores sean la cantidad total de descargas de cada una de ellas.

with open(file, 'r', encoding='utf-8') as archivo: 
    reader = csv.DictReader(archivo)
    for fila in reader:
        app_name = fila['App']
        installs = limpiar_installs(fila['Installs'])
        installs_por_app[app_name] += installs

top_10_apps = sorted(installs_por_app.items(), key=lambda x: x[1], reverse=True)[:10] 
##usa sorted con una funcion lambda
##el .items devuelve una lista de tuplas, donde cada tupla contiene una clave (nombre de la aplicación) y su correspondiente valor (número de descargas)
##sorted ordena los elementos del iterable.
## key= lambda es una función anonima que se utiliza para extraer el valor por el cual ordenar. En este caso, x[1] hace referencia al segundo elemento de cada tupla (que es el número de descargas)
##reverse = true hace que el orden sea descendente, es decir, se ordenan de mayor a menor según las descargas
###[:10] es hacer un slicing y quedarse con los primeros 10

class NodoArbol:
    def __init__(self, dato=None):
        self.dato = dato
        self.derecho = None
        self.izquierdo = None

    def agregarnodos(self, nodo): 
        if nodo.dato[0] < self.dato[0]:  ##compara valores de descargas entre el nodo actual y el nodo que quiero agregar. si el num de descargas de nodo es menor que el del nodo actual, el nodo se agrega a la izquierda
            if self.izquierdo is None: ##si no hay nodo a la izquierda del nodo actual, agrega el nuevo nodo
                self.izquierdo = nodo
            else: ##si el subarbol ya tiene un nodo, se usa recursion. Pasa al nodo izquierdo y vuelve a aplicar la comparacion de descargas. lo hace hasta que encuentra una posicion vacia en el subarbol izquierdo
                self.izquierdo.agregarnodos(nodo)
        else: ##para el subarbol derecho, el num de descargas de nodo es mayor o igual al del nodo actual. 
            if self.derecho is None:
                self.derecho = nodo
            else:
                self.derecho.agregarnodos(nodo)

class Arbol: 
    def __init__(self, nodo=None): 
        self.root = nodo ##raiz del arbol. si el arbol no esta vacio, la raiz va a ser el nodo que se le pase al crear una instancia del arbol

    def agregarnodo(self, nodo): ##agrega un nuevo nodo al arbol
        if self.root is None: ##si el arbol esta vacio, osea la raiz es none, entonces se asigna al nuevo nodo como la raiz 
            self.root = nodo
        else: ##si no esta vacio, se llama a la funcion agregarnodos de la clase nodo, y se agrega bien el nodo donde debe ir
            self.root.agregarnodos(nodo)

arbol_apps = Arbol() ##se crea una instancia de la clase arbol, root es None en un principio pq esta vacio
for app_name, installs in top_10_apps: 
    nuevo_nodo = NodoArbol((installs, app_name)) ##se crea una instancia de nodo por cada tupla (app, num)
    arbol_apps.agregarnodo(nuevo_nodo) ##se agrega el nodo con el metodo de la clase arbol que, si no esta vacio, llama al metodo de la clase nodo

print("Top 10 Aplicaciones más descargadas (Mayor a Menor):")
for i, app in enumerate(top_10_apps, 1): ##uso enumerate para que devuelva el par indice, valor pero valor aca es la tupla. 
    print(f"{i}. {app[0]}: {app[1]:,} descargas") ##imprime el nombre de la app y el numero de desargas juntop con el indice

##graficar el arbol 
def dibujar_arbol(nodo: NodoArbol, x=0, y=0, dx=2, dy=2, posiciones=None, etiquetas=None):
    ##nodo es el nodo actual, de tipo nodoarbol
    ##x e y son las coordenadas en el grafico donde hay que ubicar al nodo
    ##dx y dy son los desplazamientos para ubicar a los nodos hijos con respecto del nodo actual 
    ##posiciones es un dict que almacena las coordenadas (x, y) de cada nodo 
    ##etiquetas es un dict que almacena las etiquetas de los nodos con clave = dato del nodo (tupla), valor = str de la etiqueta del grafico
    if posiciones is None: 
        posiciones = {}
    if etiquetas is None:
        etiquetas = {}

    if nodo: ##si el nodo no es None entra
        posiciones[nodo.dato] = (x, y) ##guarda la posicion del nodo actual en el dict posiciones con clave nodo.dato y valor tupla x, y
        etiquetas[nodo.dato] = f"{nodo.dato[1]} ({nodo.dato[0]:,})" ##se crea la etiqueta para el nodo, nombre app y num de descargas

        if nodo.izquierdo: ##si el nodo tiene un hijo izquierdo, dibuja la linea desde el nodo actual hacua el hijo izquierdo desplazando las coordenadas x e y a la izquierda
            plt.plot([x, x - dx], [y, y - dy], 'k-', lw=1)
            dibujar_arbol(nodo.izquierdo, x - dx, y - dy, dx / 1.5, dy, posiciones, etiquetas) ##llama recursivo a la funcion

        if nodo.derecho: ##si el nodo tiene un hijo derecho, misma logica pero para el otro lado
            plt.plot([x, x + dx], [y, y - dy], 'k-', lw=1)
            dibujar_arbol(nodo.derecho, x + dx, y - dy, dx / 1.5, dy, posiciones, etiquetas)

    return posiciones, etiquetas ##devuelve los diccionatios que tienen la info de la posicion y las etiquetas de todos los nodos del arbol

def mostrar_arbol(nodo): ##muestra graficmnte el arbol. 
    plt.figure(figsize=(15, 10)) ##tama;o de la figura 
    posiciones, etiquetas = dibujar_arbol(nodo) ##llama a la funcion dibujar arbol que genera dos diccs

    for dato, (x, y) in posiciones.items(): ##se recorren las posiciones de cada nodo que contienen sus coordenadas
        plt.scatter(x, y, s=800, c='lightblue', edgecolors='black', zorder=3) ##se dibuja cada nodo como un circulo. s es el tama;o del nodo, c es el color de fondo y edgecolors es el borde del nodo
        plt.text(x, y - 0.4, etiquetas[dato], ha='center', fontsize=10, bbox=dict(facecolor='white', edgecolor='none', boxstyle='round,pad=0.3')) ##agrega la etoqueta al nodo mostrando el nomre de la applicacion y las descargas. x, y - 0.4 ubicacuon de la etiqueta un poquito mas abajo del nodo, ha es que la etoqueta este centrada y bbox es que crea un fondo blanco alrededor de la etoqueta para que sea legible

    plt.title("Árbol Binario: Top 10 Aplicaciones", fontsize=16) ##titulo
    plt.axis('off') ##oculta los ejes para que se vea solo el arbol
    plt.show() ##muestra el grafico

# Graficar el árbol
mostrar_arbol(arbol_apps.root)