#import
from Class_Menu import *
from funciones_pedido_inputs import *

#Menú principal - opción 2 - menú Abrir app - app Contactos

def menuContacto(telefono_operando):
    texto_contacto = "\nElija la opción que desee:"
    if len(telefono_operando.apps["Contactos"].contactos)==0:
        opciones_contacto={"1":"Agendar un nuevo contacto","2":"Ver agenda de contactos","3":"Volver al menu principal"}
    else:
        opciones_contacto = {"1":"Agendar un nuevo contacto","2":"Cambiar el nombre de un contacto existente","3":"Cambiar el numero de un contacto existente","4":"Agregar un nuevo número a un contacto existente","5":"Ver agenda de contactos","6":"Volver al menu principal"}
    menu_contacto = Menu(opciones_contacto,texto_contacto)
    opcion_contacto=menu_contacto.pedir_opcion()
    return opcion_contacto

#Menú principal - opción 2 - menú Abrir app - app Contactos - opción 1

def opcion1_menu_contacto():
    nombre=pedirNombreContacto()
    numero=pedirNumeroContacto()
    return nombre,numero

#Menú principal - opción 2 - menú Abrir app - App contactos - opción 2

def opcion2_menu_contacto(telefono_operando):
    texto_cambiar_nombre="\nElija el contacto al que le quiere cambiar el nombre: "
    opciones_contactos=telefono_operando.apps["Contactos"].contactos
    menu_contactos=Menu(opciones_contactos,texto_cambiar_nombre)
    opcion_contacto=menu_contactos.pedir_opcion()
    nombre=pedirNombreContacto()
    telefono_operando.apps["Contactos"].contactos[int(opcion_contacto)-1]["nombre"]=nombre
    
#Menú principal - opción 2 - menú Abrir app - App contactos - opción 3

def opcion3_menu_contacto(telefono_operando):
    texto_cambiar_numero="\nElija el contacto al que le quiere cambiar el número de teléfono: "
    opciones_contactos=telefono_operando.apps["Contactos"].contactos
    menu_contactos=Menu(opciones_contactos,texto_cambiar_numero)
    opcion_contacto=menu_contactos.pedir_opcion()
    if len(telefono_operando.apps["Contactos"].contactos[int(opcion_contacto)-1]["numeros"])>1:
        texto_elegir_numero="\nElija qué número de su contacto desea modificar: "
        opciones_numeros=telefono_operando.apps["Contactos"].contactos[int(opcion_contacto)-1]["numeros"]
        menu_numeros=Menu(opciones_numeros,texto_elegir_numero)
        opcion_numero=menu_numeros.pedir_opcion()
        numero=pedirNumeroContacto()
        telefono_operando.apps["Contactos"].contactos[int(opcion_contacto)-1]["numeros"][int(opcion_numero)-1]=numero
    else:
        numero=pedirNumeroContacto()
        telefono_operando.apps["Contactos"].contactos[int(opcion_contacto)-1]["numeros"]=[numero]

#Menú principal - opción 2 - menú Abrir app - App contactos - opción 4

def opcion4_menu_contacto(telefono_operando):
    texto_agregar_numero="\nElija el contacto al que le quiere agregar un nuevo número de teléfono: "
    opciones_contactos=telefono_operando.apps["Contactos"].contactos
    menu_contactos=Menu(opciones_contactos,texto_agregar_numero)
    opcion_contacto=menu_contactos.pedir_opcion()
    numero=pedirNumeroContacto()
    telefono_operando.apps["Contactos"].contactos[int(opcion_contacto)-1]["numeros"].append(numero)

#Menú principal - opción 2 - menú Abrir app - App contactos - main

def opcion_abrir_app_contacto(telefono_operando):
    sigue=True
    while sigue:
        opcion_contacto=menuContacto(telefono_operando)
        if len(telefono_operando.apps["Contactos"].contactos)==0:
            match opcion_contacto:
                case '1':
                    nombre,numero=opcion1_menu_contacto()
                    telefono_operando.apps["Contactos"].agendar_nuevo_contacto(nombre,numero)
                case "2":
                    print(telefono_operando.apps["Contactos"].ver_lista_contactos())
                case "3":
                    sigue=False
        else:
            match opcion_contacto:
                case '1':
                    nombre,numero=opcion1_menu_contacto()
                    telefono_operando.apps["Contactos"].agendar_nuevo_contacto(nombre,numero)
                case "2":
                    opcion2_menu_contacto(telefono_operando)
                case "3":
                    opcion3_menu_contacto(telefono_operando)
                case "4":
                    opcion4_menu_contacto(telefono_operando)
                case "5":
                    print(telefono_operando.apps["Contactos"].ver_lista_contactos())
                case "6":
                    sigue=False