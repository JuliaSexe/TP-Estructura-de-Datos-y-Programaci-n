import csv
from io import FileIO
import copy

class Exportador:
    def __init__(self, nombre_archivo):
        
        self.nombre_archivo = nombre_archivo

    def exportar(self, lista, modo = 'a'):

        try:
            with open(self.nombre_archivo, modo ,newline="",encoding="utf-8") as archivo:
                escritor = csv.DictWriter(archivo,fieldnames=lista[0].keys())
                ##Se fija que el archivo tenga o no encabezado y si no tiene lo escribe
                if not self.leerEncabezado():
                    escritor.writeheader()
                escritor.writerows(lista) ##escribe las filas en el archivo 
        except IOError:
            print("Error al exportar archivo")
            raise FileIO
    
    def exportarTodos(self, lista):

        try:
            with open(self.nombre_archivo, "w",newline="",encoding="utf-8") as archivo:
                escritor = csv.DictWriter(archivo,fieldnames=lista[0].keys())
                ##Se fija que el archivo tenga o no encabezado y si no tiene lo escribe
                if not self.leerEncabezado():
                    escritor.writeheader()
                escritor.writerows(lista) ##escribe las filas en el archivo 
        except IOError:
            print("Error al exportar archivo")
            raise FileIO
    
    def leer(self):

        try:
            with open(self.nombre_archivo, 'r',encoding="utf-8") as archivo:
                lector = csv.DictReader(archivo)
                datos = [fila for fila in lector] ##lee cada fila y almacena enb una lista
            return datos
        except FileNotFoundError:
            # print("El archivo no se encontró")
            return None
        except IOError:
            print("Error al leer archivo")
            raise FileIO
    
    def leerEncabezado(self): 

        try:
            with open(self.nombre_archivo, 'r') as archivo:
                primera_linea=archivo.readline().strip()
                return len(primera_linea)>0  # Si hay contenido, devuelve True
        except FileNotFoundError:
            return False  #Si el archivo no existe, no tiene encabezado

class ExportadorTelefono(Exportador): ##Clase para exportar datos especificos de telefonos a un archivo csv
    def __init__(self, nombre_archivo): ##metodo constructor 
        super().__init__(nombre_archivo)
        
    def exportar_todos(self,telefonos): ##guarda todos los telefonos a la vez, se asegura de que todos los telefonos regustrados se guarden en el archivo.  
        datos=[]
        for telefono in telefonos.values():
            telefono.__dict__
            telefono.__dict__["apps"]=telefono.nombre_ejecucion_apps()
            datos.append(telefono.__dict__) ##Junta todos los telefonos que se crearon 
        if datos: ##Chequea que haya datos para exportar
            self.exportar(datos, 'w') ##Escribe esos datos en el archivo 
    
    def exportar_unico(self, telefono):  # Guarda un solo teléfono
        dic = copy.deepcopy(telefono.__dict__)  # Crear una copia profunda del diccionario
        dic["apps"] = telefono.nombre_ejecucion_apps()  # Modificamos la copia, no el original
        datos = [dic]  # Empaquetamos los datos en una lista

        # Si hay datos, se procede a exportar
        if datos:
            self.exportar(datos)

class ExportadorMensaje(Exportador): 
    def __init__(self, nombre_archivo):
        super().__init__(nombre_archivo)
    def exportar_mensajes(self, nuevos_mensajes):
        mensajes_dict = {(m["id_comunicacion"], m["estado"]): m for m in nuevos_mensajes}
        mensajes_actualizados = list(mensajes_dict.values())
        if mensajes_actualizados:
            self.exportarTodos(mensajes_actualizados)
        else:
            self.limpiar_csv()
    
    def limpiar_csv(self):
        # Leer el encabezado
        with open(self.nombre_archivo, 'r', newline='', encoding='utf-8') as file:
            lines = file.readlines()
        
        # Si hay líneas (o sea, el archivo no está vacío), conservar el encabezado
        if lines:
            encabezado = lines[0]
            # Reescribir el archivo con solo el encabezado
            with open(self.nombre_archivo, 'w', newline='', encoding='utf-8') as file:
                file.write(encabezado)  # Solo escribe el encabezado